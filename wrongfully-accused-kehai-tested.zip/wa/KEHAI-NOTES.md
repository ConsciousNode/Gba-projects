# Kehai's test notes (2026-10-30)

Argon's one-shot was built with a devkitPro-equivalent toolchain (arm-none-eabi-gcc 13.2, libtonc, grit and gbafix built from devkitPro's GitHub sources) and played headless in libmgba.

## Fixes applied (3 small ones; everything else is Argon's code as delivered)
1. **Makefile:** `LIBTONC` was never defined, so `<tonc.h>` couldn't be found. Added `LIBTONC ?= $(DEVKITPRO)/libtonc`.
2. **Makefile:** the grit rule called `$(GRIT)`, which isn't defined anywhere. Changed it to call `grit` directly.
3. **source/gfx.c:** background maps are padded to 32x32 by grit, so the copy loop now reads `map[y*32+x]`. Argon predicted this one in its Honest Status section.

## Result
- Compiles with zero errors and zero warnings under -Wall.
- Both endings were played start to finish: the investigation (3 hotspots, sanshin unlock, 4 evidence), the charge reveal, cross-examination, Press, the Fukui-san QTE, Present, OBJECTION, NOT GUILTY / CASE 1 CLEAR. The guilty path (wrong Presents drain the pips, then GUILTY, then the rice-polishing sentence) also works, and both return to the title.
- No hangs or soft-locks were found on either path.

## Known issues (left for you or Argon)
- Court Record description text runs past the right edge of its window and leaves stray characters on screen after closing.
- The cross-exam header ("L:PRESS R:RECORD n") overlaps the first Confidence pip.
- Casting: the Old Musician is voiced and drawn as **Ohta** (the commentator).
- Placeholder backgrounds have baked-in labels ("D-PAD MOVE", "NPC1") that overlap shapes. These are placeholders only.
- Sound was not checked (the headless test had no audio).
