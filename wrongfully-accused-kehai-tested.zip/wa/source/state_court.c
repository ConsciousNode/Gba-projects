/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * source/state_court.c
 * What this file does: Drives the courtroom phase: Iron Chef "TODAY'S CHARGE
 * IS... ALLEZ LAW!" screen, 4-statement testimony, Press (L), Court Record
 * Present (R), Commentary QTE, and 5-pip Confidence meter.
 * What this file does NOT do: Implement multi-witness or multi-day trials.
 */

#include <tonc.h>
#include "config.h"
#include "game.h"
#include "gfx.h"
#include "text.h"
#include "sound.h"
#include "evidence.h"
#include "script_vm.h"
#include "script_data.h"
#include "state_court.h"

static int s_charge_drawn = 0;
static int s_cross_hud_drawn = 0;

static void draw_charge_reveal_screen(void)
{
    gfx_set_bg(BG_ID_CHARGE);
    gfx_set_portrait(PORTRAIT_MAGISTRATE_SHOUT);
    gfx_bg0_clear();

    gfx_bg0_draw_box(1, 0, 28, 3, PAL_BANK_TEXT);
    text_print(5, 1, "TODAY'S CHARGE IS...", PAL_BANK_HIGHLIGHT);

    gfx_bg0_draw_box(1, 11, 28, 9, PAL_BANK_TEXT);
    text_print(2, 12, vm_get_charge_text(), PAL_BANK_TEXT);
    text_print(8, 16, "\"ALLEZ LAW!\"", PAL_BANK_HIGHLIGHT);
    text_print(9, 18, "[PRESS A]", PAL_BANK_TEXT);
}

static void draw_cross_exam_header(int stmt_idx)
{
    char buf[20];
    int i;
    const char *prefix = "L:PRESS R:RECORD ";

    gfx_bg0_draw_box(0, 0, 19, 3, PAL_BANK_TEXT);
    for (i = 0; prefix[i] != '\0'; i++) {
        buf[i] = prefix[i];
    }
    buf[i++] = (char)('1' + stmt_idx);
    buf[i++] = '/';
    buf[i++] = '4';
    buf[i]   = '\0';

    text_print(1, 1, buf, PAL_BANK_HIGHLIGHT);
}

void state_court_enter(void)
{
    gfx_sprites_hide_all();
    gfx_set_bg(BG_ID_COURT);
    gfx_set_portrait(PORTRAIT_NONE);
    gfx_bg0_clear();

    s_charge_drawn = 0;
    s_cross_hud_drawn = 0;

    gfx_set_confidence_pips(g_game.confidence, CONFIDENCE_MAX_PIPS, 1);
    vm_jump(SCENE_COURT_START);
    vm_step();
}

void state_court_update(void)
{
    VmMode mode = vm_get_mode();

    /* Keep Confidence pips synced in OAM shadow */
    gfx_set_confidence_pips(
        g_game.confidence,
        CONFIDENCE_MAX_PIPS,
        (mode != VM_MODE_CHARGE_REVEAL)
    );

    if (mode == VM_MODE_CHARGE_REVEAL) {
        if (!s_charge_drawn) {
            draw_charge_reveal_screen();
            s_charge_drawn = 1;
        }
        if (key_hit(KEY_A) || key_hit(KEY_START)) {
            sound_play(SFX_OBJECTION);
            gfx_bg0_clear();
            s_charge_drawn = 0;
            vm_resume_from_charge_reveal();
            vm_step();
        }
        return;
    }

    if (mode == VM_MODE_TESTIMONY) {
        int tid = vm_get_active_testimony_id();
        int sid = vm_get_active_stmt_index();
        const TestimonyDef *tdef = &g_testimonies[tid];
        const StatementDef *sdef = &tdef->statements[sid];

        if (!s_cross_hud_drawn) {
            draw_cross_exam_header(sid);
            s_cross_hud_drawn = 1;
        }

        text_box_update();

        /* Handle open Court Record (Present mode) */
        if (evidence_ui_is_open()) {
            int chosen_ev = evidence_ui_update();
            if (chosen_ev >= 0) {
                s_cross_hud_drawn = 0;
                gfx_bg0_clear_rect(0, 0, 19, 3);
                if (sdef->contradicted_by_ev == chosen_ev) {
                    vm_jump(sdef->success_pc);
                } else {
                    vm_jump(tdef->wrong_present_pc);
                }
                vm_step();
            }
            return;
        }

        if (key_hit(KEY_L)) {
            /* Press current statement */
            sound_play(SFX_OBJECTION);
            s_cross_hud_drawn = 0;
            gfx_bg0_clear_rect(0, 0, 19, 3);
            vm_jump(sdef->press_pc);
            vm_step();
            return;
        }

        if (key_hit(KEY_R)) {
            /* Open Court Record to Present */
            evidence_ui_open(RECORD_MODE_PRESENT);
            return;
        }

        if (key_hit(KEY_RIGHT)) {
            sound_play(SFX_BLIP);
            vm_set_active_stmt_index((sid + 1) & 3);
            s_cross_hud_drawn = 0;
            return;
        }

        if (key_hit(KEY_LEFT)) {
            sound_play(SFX_BLIP);
            vm_set_active_stmt_index((sid + 3) & 3);
            s_cross_hud_drawn = 0;
            return;
        }

        if (key_hit(KEY_A)) {
            if (text_box_is_typing()) {
                text_box_finish_line();
            } else {
                sound_play(SFX_BLIP);
                vm_set_active_stmt_index((sid + 1) & 3);
                s_cross_hud_drawn = 0;
            }
            return;
        }

        return;
    }

    s_cross_hud_drawn = 0;
    vm_step();
}
