/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * source/script_vm.c
 * What this file does: Executes compiled .wa script tables from ROM
 * (g_script_insns and g_testimonies in source/script_data.c).
 * What this file does NOT do: Allocate memory dynamically or parse text strings.
 */

#include <tonc.h>
#include "config.h"
#include "game.h"
#include "gfx.h"
#include "text.h"
#include "sound.h"
#include "evidence.h"
#include "qte.h"
#include "script_vm.h"
#include "script_data.h"

static u32 s_pc = 0;
static VmMode s_mode = VM_MODE_IDLE;
static u8 s_flags[SCRIPT_FLAG_COUNT];
static int s_active_testimony = 0;
static int s_active_stmt = 0;
static const char *s_charge_text = "";

static const char *speaker_id_to_name(SpeakerId spk)
{
    switch (spk) {
    case SPEAKER_NARRATOR:   return NAME_NARRATOR;
    case SPEAKER_MUKOU:      return NAME_MUKOU;
    case SPEAKER_MAGISTRATE: return NAME_MAGISTRATE;
    case SPEAKER_SCRIBE:     return NAME_SCRIBE;
    case SPEAKER_WITNESS:    return NAME_WITNESS;
    case SPEAKER_OHTA:       return NAME_OHTA;
    case SPEAKER_FUKUI:      return NAME_FUKUI;
    }
    return "";
}

void vm_init(void)
{
    int i;
    s_pc = SCENE_INTRO;
    s_mode = VM_MODE_IDLE;
    for (i = 0; i < SCRIPT_FLAG_COUNT; i++) {
        s_flags[i] = 0;
    }
    s_active_testimony = 0;
    s_active_stmt = 0;
    s_charge_text = "";
}

void vm_jump(u32 target_pc)
{
    if (target_pc < SCRIPT_INSN_COUNT) {
        s_pc = target_pc;
        s_mode = VM_MODE_IDLE;
    }
}

VmMode vm_get_mode(void)
{
    return s_mode;
}

void vm_resume_from_charge_reveal(void)
{
    if (s_mode == VM_MODE_CHARGE_REVEAL) {
        s_mode = VM_MODE_IDLE;
    }
}

int vm_get_flag(int flag_id)
{
    if (flag_id < 0 || flag_id >= SCRIPT_FLAG_COUNT) {
        return 0;
    }
    return s_flags[flag_id];
}

void vm_set_flag(int flag_id, int value)
{
    if (flag_id >= 0 && flag_id < SCRIPT_FLAG_COUNT) {
        s_flags[flag_id] = (u8)(value ? 1 : 0);
    }
}

int vm_get_active_testimony_id(void)
{
    return s_active_testimony;
}

int vm_get_active_stmt_index(void)
{
    return s_active_stmt;
}

const char *vm_get_statement_text(int testimony_id, int stmt_idx)
{
    const StatementDef *st;
    if (testimony_id < 0 || testimony_id >= SCRIPT_TESTIMONY_COUNT) {
        return "";
    }
    if (stmt_idx < 0 || stmt_idx >= 4) {
        return "";
    }
    st = &g_testimonies[testimony_id].statements[stmt_idx];
    if (st->revise_flag_id >= 0 && vm_get_flag(st->revise_flag_id) && st->revised_text != NULL) {
        return st->revised_text;
    }
    return st->text;
}

void vm_set_active_stmt_index(int stmt_idx)
{
    if (stmt_idx < 0) stmt_idx = 3;
    if (stmt_idx > 3) stmt_idx = 0;
    s_active_stmt = stmt_idx;
    gfx_set_portrait(PORTRAIT_WITNESS_NEUTRAL);
    text_box_start(
        NAME_WITNESS,
        vm_get_statement_text(s_active_testimony, s_active_stmt)
    );
}

const char *vm_get_charge_text(void)
{
    return s_charge_text;
}

void vm_step(void)
{
    if (s_mode == VM_MODE_DIALOGUE) {
        text_box_update();
        if (key_hit(KEY_A)) {
            if (text_box_is_typing()) {
                text_box_finish_line();
            } else {
                sound_play(SFX_BLIP);
                s_mode = VM_MODE_IDLE;
            }
        }
        return;
    }

    if (s_mode == VM_MODE_QTE) {
        u32 next_pc = s_pc;
        QteResult res = qte_update(&next_pc);
        if (res == QTE_STATE_WON || res == QTE_STATE_LOST) {
            s_pc = next_pc;
            s_mode = VM_MODE_IDLE;
        }
        return;
    }

    while (s_mode == VM_MODE_IDLE && s_pc < SCRIPT_INSN_COUNT) {
        const ScriptInsn *insn = &g_script_insns[s_pc++];

        switch (insn->op) {
        case OP_SAY:
            text_box_start(speaker_id_to_name((SpeakerId)insn->arg1), insn->text);
            s_mode = VM_MODE_DIALOGUE;
            break;

        case OP_PORTRAIT:
            gfx_set_portrait((PortraitId)insn->arg1);
            break;

        case OP_BG:
            gfx_set_bg((BgId)insn->arg1);
            break;

        case OP_SFX:
            sound_play((SfxId)insn->arg1);
            break;

        case OP_GIVE:
            evidence_give(insn->arg1);
            break;

        case OP_FLAG_SET:
            vm_set_flag(insn->arg1, 1);
            break;

        case OP_IF_HAS_GOTO:
            if (evidence_has(insn->arg1)) {
                s_pc = (u32)insn->arg2;
            }
            break;

        case OP_IF_FLAG_GOTO:
            if (vm_get_flag(insn->arg1)) {
                s_pc = (u32)insn->arg2;
            }
            break;

        case OP_GOTO:
            if ((u32)insn->arg1 == SCENE_COURT_START && g_game.state != STATE_COURT) {
                s_pc = (u32)insn->arg1;
                game_change_state(STATE_COURT);
                return;
            }
            s_pc = (u32)insn->arg1;
            break;

        case OP_CONFIDENCE:
            g_game.confidence += insn->arg1;
            if (g_game.confidence > CONFIDENCE_MAX_PIPS) {
                g_game.confidence = CONFIDENCE_MAX_PIPS;
            }
            if (g_game.confidence < 0) {
                g_game.confidence = 0;
            }
            break;

        case OP_QTE:
            qte_start(
                (QteButton)insn->arg1,
                insn->arg2,
                (u32)insn->arg3,
                (u32)insn->arg4
            );
            s_mode = VM_MODE_QTE;
            break;

        case OP_CHARGE_REVEAL:
            s_charge_text = insn->text ? insn->text : "";
            s_mode = VM_MODE_CHARGE_REVEAL;
            break;

        case OP_TESTIMONY:
            s_active_testimony = insn->arg1;
            s_active_stmt = 0;
            vm_set_active_stmt_index(0);
            s_mode = VM_MODE_TESTIMONY;
            break;

        case OP_INVESTIGATE:
            text_box_hide();
            gfx_set_portrait(PORTRAIT_NONE);
            s_mode = VM_MODE_INVESTIGATE;
            break;

        case OP_RETURN_TESTIMONY:
            if (g_game.confidence <= 0) {
                s_pc = SCENE_NO_CONFIDENCE;
                s_mode = VM_MODE_IDLE;
            } else {
                vm_set_active_stmt_index(s_active_stmt);
                s_mode = VM_MODE_TESTIMONY;
            }
            break;

        case OP_ENDING:
            g_game.verdict_is_good = insn->arg1;
            game_change_state(STATE_VERDICT);
            return;
        }
    }
}
