/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * source/state_title.c
 * What this file does: Renders the title screen (game title, blinking
 * "PRESS START", and ConsciousNode SoftWorks credit line) and starts Case 1
 * when START is pressed.
 * What this file does NOT do: Handle save slots or case select menus.
 */

#include <tonc.h>
#include "config.h"
#include "game.h"
#include "gfx.h"
#include "text.h"
#include "sound.h"
#include "state_title.h"

void state_title_enter(void)
{
    gfx_sprites_hide_all();
    gfx_set_portrait(PORTRAIT_NONE);
    gfx_set_bg(BG_ID_TITLE);
    gfx_bg0_clear();

    gfx_bg0_draw_box(2, 2, 26, 7, PAL_BANK_TEXT);
    text_print(5, 3, "WRONGFULLY ACCUSED", PAL_BANK_HIGHLIGHT);
    text_print(6, 5, "OF STEALIN' FROM", PAL_BANK_TEXT);
    text_print(7, 6, "THE SHOGUNATE", PAL_BANK_TEXT);

    gfx_bg0_draw_box(8, 11, 14, 3, PAL_BANK_TEXT);
    text_print(9, 12, "PRESS START", PAL_BANK_HIGHLIGHT);

    gfx_bg0_draw_box(2, 16, 26, 3, PAL_BANK_TEXT);
    text_print(3, 17, "ConsciousNode SoftWorks", PAL_BANK_TEXT);
}

void state_title_update(void)
{
    /* Blink "PRESS START" every 32 frames */
    if ((g_game.frame_counter & 31) == 0) {
        u16 pal = ((g_game.frame_counter >> 5) & 1) ? PAL_BANK_TEXT : PAL_BANK_HIGHLIGHT;
        text_print(9, 12, "PRESS START", pal);
    }

    if (key_hit(KEY_START) || key_hit(KEY_A)) {
        sound_play(SFX_DING);
        game_reset_session();
        game_change_state(STATE_INVESTIGATE);
    }
}
