/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * source/gfx.c
 * What this file does: Manages Mode 0 background layers (BG0 text/UI, BG1
 * character portrait, BG2 scene background) and the 128-entry OAM shadow buffer.
 * All hardware VRAM, Palette RAM, and OAM writes occur inside gfx_vblank_flush().
 * What this file does NOT do: Write to VRAM or OAM during active draw.
 */

#include <tonc.h>
#include "config.h"
#include "gfx.h"
#include "text.h"

/* Grit-generated headers from graphics/ PNG assets */
#include "bg_title.h"
#include "bg_teahouse.h"
#include "bg_court.h"
#include "bg_charge.h"
#include "bg_verdict.h"

#include "mukou_neutral.h"
#include "mukou_sweat.h"
#include "mukou_confident.h"
#include "magistrate_neutral.h"
#include "magistrate_shout.h"
#include "scribe_neutral.h"
#include "scribe_smug.h"
#include "witness_neutral.h"
#include "witness_sweat.h"
#include "ohta_neutral.h"
#include "fukui_neutral.h"

#include "ev_plum_jar.h"
#include "ev_tea_receipt.h"
#include "ev_nori_scrap.h"
#include "ev_guard_log.h"
#include "spr_cursor.h"
#include "spr_pip_full.h"
#include "spr_pip_empty.h"
#include "spr_qte.h"

/* OBJ tile indices (each 16x16 4bpp sprite occupies 4 tiles) */
#define OBJ_TILE_CURSOR         0
#define OBJ_TILE_PIP_FULL       4
#define OBJ_TILE_PIP_EMPTY      8
#define OBJ_TILE_QTE            12
#define OBJ_TILE_EV_BASE        16  /* 16, 20, 24, 28 */

/* OBJ palette banks */
#define OBJ_PAL_CURSOR          0
#define OBJ_PAL_PIP_FULL        1
#define OBJ_PAL_PIP_EMPTY       2
#define OBJ_PAL_QTE             3
#define OBJ_PAL_EV_BASE         4   /* 4, 5, 6, 7 */

/* Portrait position on BG1 (in 8x8 tile coordinates: centered at X=11, Y=3) */
#define PORTRAIT_TILE_X         11
#define PORTRAIT_TILE_Y         3
#define PORTRAIT_TILE_W         8
#define PORTRAIT_TILE_H         8

typedef struct {
    const unsigned int *tiles;
    unsigned int tiles_len;
    const unsigned short *map;
    unsigned int map_len;
    const unsigned short *pal;
    unsigned int pal_len;
} BgAsset;

typedef struct {
    const unsigned int *tiles;
    unsigned int tiles_len;
    const unsigned short *pal;
    unsigned int pal_len;
} TilePalAsset;

static const BgAsset s_bg_assets[] = {
    [BG_ID_NONE]     = { NULL, 0, NULL, 0, NULL, 0 },
    [BG_ID_TITLE]    = { bg_titleTiles, bg_titleTilesLen, bg_titleMap, bg_titleMapLen, bg_titlePal, bg_titlePalLen },
    [BG_ID_TEAHOUSE] = { bg_teahouseTiles, bg_teahouseTilesLen, bg_teahouseMap, bg_teahouseMapLen, bg_teahousePal, bg_teahousePalLen },
    [BG_ID_COURT]    = { bg_courtTiles, bg_courtTilesLen, bg_courtMap, bg_courtMapLen, bg_courtPal, bg_courtPalLen },
    [BG_ID_CHARGE]   = { bg_chargeTiles, bg_chargeTilesLen, bg_chargeMap, bg_chargeMapLen, bg_chargePal, bg_chargePalLen },
    [BG_ID_VERDICT]  = { bg_verdictTiles, bg_verdictTilesLen, bg_verdictMap, bg_verdictMapLen, bg_verdictPal, bg_verdictPalLen },
};

static const TilePalAsset s_portrait_assets[] = {
    [PORTRAIT_NONE]               = { NULL, 0, NULL, 0 },
    [PORTRAIT_MUKOU_NEUTRAL]      = { mukou_neutralTiles, mukou_neutralTilesLen, mukou_neutralPal, mukou_neutralPalLen },
    [PORTRAIT_MUKOU_SWEAT]        = { mukou_sweatTiles, mukou_sweatTilesLen, mukou_sweatPal, mukou_sweatPalLen },
    [PORTRAIT_MUKOU_CONFIDENT]    = { mukou_confidentTiles, mukou_confidentTilesLen, mukou_confidentPal, mukou_confidentPalLen },
    [PORTRAIT_MAGISTRATE_NEUTRAL] = { magistrate_neutralTiles, magistrate_neutralTilesLen, magistrate_neutralPal, magistrate_neutralPalLen },
    [PORTRAIT_MAGISTRATE_SHOUT]   = { magistrate_shoutTiles, magistrate_shoutTilesLen, magistrate_shoutPal, magistrate_shoutPalLen },
    [PORTRAIT_SCRIBE_NEUTRAL]     = { scribe_neutralTiles, scribe_neutralTilesLen, scribe_neutralPal, scribe_neutralPalLen },
    [PORTRAIT_SCRIBE_SMUG]        = { scribe_smugTiles, scribe_smugTilesLen, scribe_smugPal, scribe_smugPalLen },
    [PORTRAIT_WITNESS_NEUTRAL]    = { witness_neutralTiles, witness_neutralTilesLen, witness_neutralPal, witness_neutralPalLen },
    [PORTRAIT_WITNESS_SWEAT]      = { witness_sweatTiles, witness_sweatTilesLen, witness_sweatPal, witness_sweatPalLen },
    [PORTRAIT_OHTA_NEUTRAL]       = { ohta_neutralTiles, ohta_neutralTilesLen, ohta_neutralPal, ohta_neutralPalLen },
    [PORTRAIT_FUKUI_NEUTRAL]      = { fukui_neutralTiles, fukui_neutralTilesLen, fukui_neutralPal, fukui_neutralPalLen },
};

static const TilePalAsset s_ev_icon_assets[ICON_COUNT] = {
    [ICON_PLUM_JAR]    = { ev_plum_jarTiles, ev_plum_jarTilesLen, ev_plum_jarPal, ev_plum_jarPalLen },
    [ICON_TEA_RECEIPT] = { ev_tea_receiptTiles, ev_tea_receiptTilesLen, ev_tea_receiptPal, ev_tea_receiptPalLen },
    [ICON_NORI_SCRAP]  = { ev_nori_scrapTiles, ev_nori_scrapTilesLen, ev_nori_scrapPal, ev_nori_scrapPalLen },
    [ICON_GUARD_LOG]   = { ev_guard_logTiles, ev_guard_logTilesLen, ev_guard_logPal, ev_guard_logPalLen },
};

static OBJ_ATTR s_oam_shadow[128];
static u16 s_bg0_shadow[32 * 32];

static BgId s_pending_bg = BG_ID_NONE;
static PortraitId s_pending_portrait = PORTRAIT_NONE;

static int s_vram_init_pending = 1;
static int s_bg_dirty = 0;
static int s_portrait_dirty = 0;
static int s_bg0_dirty = 0;
static int s_oam_dirty = 0;

void gfx_init(void)
{
    REG_BG0CNT = BG_CBB(BG0_CBB) | BG_SBB(BG0_SBB) | BG_4BPP | BG_REG_32x32 | BG_PRIO(0);
    REG_BG1CNT = BG_CBB(BG1_CBB) | BG_SBB(BG1_SBB) | BG_4BPP | BG_REG_32x32 | BG_PRIO(1);
    REG_BG2CNT = BG_CBB(BG2_CBB) | BG_SBB(BG2_SBB) | BG_4BPP | BG_REG_32x32 | BG_PRIO(2);

    REG_BG0HOFS = 0;
    REG_BG0VOFS = 0;
    REG_BG1HOFS = 0;
    REG_BG1VOFS = 0;
    REG_BG2HOFS = 0;
    REG_BG2VOFS = 0;

    oam_init(s_oam_shadow, 128);
    gfx_bg0_clear();

    s_vram_init_pending = 1;
    s_oam_dirty = 1;
}

static void upload_static_obj_assets_vblank(void)
{
    int i;

    /* Clear transparent tile 0 in BG1 and BG2 charblocks */
    memset32(&tile_mem[BG1_CBB][0], 0, 8);
    memset32(&tile_mem[BG2_CBB][0], 0, 8);
    memset32(&se_mem[BG1_SBB][0], 0, (32 * 32) / 2);
    memset32(&se_mem[BG2_SBB][0], 0, (32 * 32) / 2);

    /* Upload static UI sprites into OBJ VRAM (tile_mem[4]) */
    memcpy32(&tile_mem[4][OBJ_TILE_CURSOR], spr_cursorTiles, spr_cursorTilesLen / 4);
    memcpy16(pal_obj_bank[OBJ_PAL_CURSOR], spr_cursorPal, 16);

    memcpy32(&tile_mem[4][OBJ_TILE_PIP_FULL], spr_pip_fullTiles, spr_pip_fullTilesLen / 4);
    memcpy16(pal_obj_bank[OBJ_PAL_PIP_FULL], spr_pip_fullPal, 16);

    memcpy32(&tile_mem[4][OBJ_TILE_PIP_EMPTY], spr_pip_emptyTiles, spr_pip_emptyTilesLen / 4);
    memcpy16(pal_obj_bank[OBJ_PAL_PIP_EMPTY], spr_pip_emptyPal, 16);

    memcpy32(&tile_mem[4][OBJ_TILE_QTE], spr_qteTiles, spr_qteTilesLen / 4);
    memcpy16(pal_obj_bank[OBJ_PAL_QTE], spr_qtePal, 16);

    for (i = 0; i < ICON_COUNT; i++) {
        memcpy32(
            &tile_mem[4][OBJ_TILE_EV_BASE + i * 4],
            s_ev_icon_assets[i].tiles,
            s_ev_icon_assets[i].tiles_len / 4
        );
        memcpy16(
            pal_obj_bank[OBJ_PAL_EV_BASE + i],
            s_ev_icon_assets[i].pal,
            16
        );
    }
}

void gfx_vblank_flush(void)
{
    if (s_vram_init_pending) {
        upload_static_obj_assets_vblank();
        s_vram_init_pending = 0;
    }

    if (s_bg_dirty) {
        const BgAsset *asset = &s_bg_assets[s_pending_bg];
        if (asset->tiles != NULL) {
            int y, x;
            memcpy32(&tile_mem[BG2_CBB][0], asset->tiles, asset->tiles_len / 4);
            memcpy16(pal_bg_bank[PAL_BANK_BG], asset->pal, 16);

            /* grit -mLs pads the map to 32x32; copy the visible 30x20 into the 32x32 screenblock with PAL_BANK_BG */
            for (y = 0; y < 20; y++) {
                for (x = 0; x < 30; x++) {
                    u16 raw = asset->map[y * 32 + x] & 0x0FFF;
                    se_mem[BG2_SBB][y * 32 + x] = raw | SE_PALBANK(PAL_BANK_BG);
                }
            }
        }
        s_bg_dirty = 0;
    }

    if (s_portrait_dirty) {
        int ty, tx;
        const TilePalAsset *p = &s_portrait_assets[s_pending_portrait];
        if (p->tiles == NULL) {
            for (ty = 0; ty < PORTRAIT_TILE_H; ty++) {
                for (tx = 0; tx < PORTRAIT_TILE_W; tx++) {
                    se_mem[BG1_SBB][(PORTRAIT_TILE_Y + ty) * 32 + (PORTRAIT_TILE_X + tx)] = 0;
                }
            }
        } else {
            u16 tile_idx = 1;
            memcpy32(&tile_mem[BG1_CBB][1], p->tiles, p->tiles_len / 4);
            memcpy16(pal_bg_bank[PAL_BANK_PORTRAIT], p->pal, 16);
            for (ty = 0; ty < PORTRAIT_TILE_H; ty++) {
                for (tx = 0; tx < PORTRAIT_TILE_W; tx++) {
                    se_mem[BG1_SBB][(PORTRAIT_TILE_Y + ty) * 32 + (PORTRAIT_TILE_X + tx)] =
                        tile_idx | SE_PALBANK(PAL_BANK_PORTRAIT);
                    tile_idx++;
                }
            }
        }
        s_portrait_dirty = 0;
    }

    if (s_bg0_dirty) {
        memcpy16(&se_mem[BG0_SBB][0], s_bg0_shadow, 32 * 32);
        s_bg0_dirty = 0;
    }

    if (s_oam_dirty) {
        oam_copy(oam_mem, s_oam_shadow, 128);
        s_oam_dirty = 0;
    }
}

void gfx_set_bg(BgId bg_id)
{
    s_pending_bg = bg_id;
    s_bg_dirty = 1;
}

void gfx_set_portrait(PortraitId portrait_id)
{
    s_pending_portrait = portrait_id;
    s_portrait_dirty = 1;
}

void gfx_bg0_clear(void)
{
    int i;
    for (i = 0; i < 32 * 32; i++) {
        s_bg0_shadow[i] = UI_TILE_TRANSPARENT;
    }
    s_bg0_dirty = 1;
}

void gfx_bg0_clear_rect(int tx, int ty, int tw, int th)
{
    int y, x;
    for (y = ty; y < ty + th; y++) {
        if (y < 0 || y >= 32) continue;
        for (x = tx; x < tx + tw; x++) {
            if (x < 0 || x >= 32) continue;
            s_bg0_shadow[y * 32 + x] = UI_TILE_TRANSPARENT;
        }
    }
    s_bg0_dirty = 1;
}

void gfx_bg0_put_tile(int tx, int ty, u16 tile_id, u16 pal_bank)
{
    if (tx < 0 || tx >= 32 || ty < 0 || ty >= 32) {
        return;
    }
    s_bg0_shadow[ty * 32 + tx] = (tile_id & 0x03FF) | SE_PALBANK(pal_bank);
    s_bg0_dirty = 1;
}

void gfx_bg0_draw_box(int tx, int ty, int tw, int th, u16 pal_bank)
{
    int y, x;
    for (y = ty; y < ty + th; y++) {
        for (x = tx; x < tx + tw; x++) {
            u16 tid = UI_TILE_BOX_FILL;
            if ((y == ty || y == ty + th - 1) && (x == tx || x == tx + tw - 1)) {
                tid = UI_TILE_BOX_CORNER;
            } else if (y == ty || y == ty + th - 1) {
                tid = UI_TILE_BOX_BORDER_H;
            } else if (x == tx || x == tx + tw - 1) {
                tid = UI_TILE_BOX_BORDER_V;
            }
            gfx_bg0_put_tile(x, y, tid, pal_bank);
        }
    }
}

void gfx_sprites_hide_all(void)
{
    int i;
    for (i = 0; i < 128; i++) {
        obj_hide(&s_oam_shadow[i]);
    }
    s_oam_dirty = 1;
}

void gfx_set_cursor_sprite(int x, int y, int visible)
{
    OBJ_ATTR *obj = &s_oam_shadow[OAM_IDX_CURSOR];
    if (!visible) {
        obj_hide(obj);
    } else {
        obj_set_attr(
            obj,
            ATTR0_SQUARE | ATTR0_4BPP | ATTR0_Y(y & 0xFF),
            ATTR1_SIZE_16 | ATTR1_X(x & 0x1FF),
            ATTR2_BUILD(OBJ_TILE_CURSOR, OBJ_PAL_CURSOR, 0)
        );
    }
    s_oam_dirty = 1;
}

void gfx_set_qte_sprite(int x, int y, int visible)
{
    OBJ_ATTR *obj = &s_oam_shadow[OAM_IDX_QTE];
    if (!visible) {
        obj_hide(obj);
    } else {
        obj_set_attr(
            obj,
            ATTR0_SQUARE | ATTR0_4BPP | ATTR0_Y(y & 0xFF),
            ATTR1_SIZE_16 | ATTR1_X(x & 0x1FF),
            ATTR2_BUILD(OBJ_TILE_QTE, OBJ_PAL_QTE, 0)
        );
    }
    s_oam_dirty = 1;
}

void gfx_set_evidence_icon_sprite(int x, int y, EvidenceIconId icon, int visible)
{
    OBJ_ATTR *obj = &s_oam_shadow[OAM_IDX_EVIDENCE_ICON];
    if (!visible || icon < 0 || icon >= ICON_COUNT) {
        obj_hide(obj);
    } else {
        obj_set_attr(
            obj,
            ATTR0_SQUARE | ATTR0_4BPP | ATTR0_Y(y & 0xFF),
            ATTR1_SIZE_16 | ATTR1_X(x & 0x1FF),
            ATTR2_BUILD(OBJ_TILE_EV_BASE + icon * 4, OBJ_PAL_EV_BASE + icon, 0)
        );
    }
    s_oam_dirty = 1;
}

void gfx_set_confidence_pips(int current_pips, int max_pips, int visible)
{
    int i;
    for (i = 0; i < CONFIDENCE_MAX_PIPS; i++) {
        OBJ_ATTR *obj = &s_oam_shadow[OAM_IDX_PIP_BASE + i];
        if (!visible || i >= max_pips) {
            obj_hide(obj);
        } else {
            int is_full = (i < current_pips);
            u16 tid = is_full ? OBJ_TILE_PIP_FULL : OBJ_TILE_PIP_EMPTY;
            u16 pal = is_full ? OBJ_PAL_PIP_FULL : OBJ_PAL_PIP_EMPTY;
            int px = 152 + i * 17;
            int py = 4;
            obj_set_attr(
                obj,
                ATTR0_SQUARE | ATTR0_4BPP | ATTR0_Y(py),
                ATTR1_SIZE_16 | ATTR1_X(px),
                ATTR2_BUILD(tid, pal, 0)
            );
        }
    }
    s_oam_dirty = 1;
}
