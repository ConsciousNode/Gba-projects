/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * source/evidence.c
 * What this file does: Manages the 16-slot Court Record array and draws/updates
 * the modal Court Record overlay on BG0 + OBJ icon sprite.
 * What this file does NOT do: Evaluate testimony contradictions directly (it
 * returns the selected evidence ID to state_court.c).
 */

#include <tonc.h>
#include "config.h"
#include "evidence.h"
#include "gfx.h"
#include "text.h"
#include "sound.h"
#include "script_data.h"

#define REC_BOX_X   1
#define REC_BOX_Y   1
#define REC_BOX_W   28
#define REC_BOX_H   10

static int s_slots[COURT_RECORD_MAX_SLOTS];
static int s_count = 0;
static RecordUiMode s_ui_mode = RECORD_MODE_CLOSED;
static int s_cursor = 0;

void evidence_init(void)
{
    int i;
    for (i = 0; i < COURT_RECORD_MAX_SLOTS; i++) {
        s_slots[i] = -1;
    }
    s_count = 0;
    s_ui_mode = RECORD_MODE_CLOSED;
    s_cursor = 0;
}

int evidence_has(int ev_id)
{
    int i;
    for (i = 0; i < s_count; i++) {
        if (s_slots[i] == ev_id) {
            return 1;
        }
    }
    return 0;
}

int evidence_give(int ev_id)
{
    if (ev_id < 0 || ev_id >= EVIDENCE_COUNT) {
        return 0;
    }
    if (evidence_has(ev_id)) {
        return 0;
    }
    if (s_count >= COURT_RECORD_MAX_SLOTS) {
        return 0;
    }
    s_slots[s_count++] = ev_id;
    return 1;
}

int evidence_count(void)
{
    return s_count;
}

int evidence_get_slot(int index)
{
    if (index < 0 || index >= s_count) {
        return -1;
    }
    return s_slots[index];
}

static void render_record_ui(void)
{
    gfx_bg0_draw_box(REC_BOX_X, REC_BOX_Y, REC_BOX_W, REC_BOX_H, PAL_BANK_TEXT);

    if (s_ui_mode == RECORD_MODE_PRESENT) {
        text_print(REC_BOX_X + 1, REC_BOX_Y, "COURT RECORD [A:PRESENT]", PAL_BANK_HIGHLIGHT);
    } else {
        text_print(REC_BOX_X + 1, REC_BOX_Y, "COURT RECORD [B:CLOSE]", PAL_BANK_HIGHLIGHT);
    }

    if (s_count == 0) {
        gfx_set_evidence_icon_sprite(0, 0, ICON_PLUM_JAR, 0);
        text_print(REC_BOX_X + 2, REC_BOX_Y + 4, "No evidence collected yet.", PAL_BANK_TEXT);
        return;
    }

    {
        int ev_id = s_slots[s_cursor];
        const EvidenceDef *def = &g_evidence_defs[ev_id];
        char num_buf[6];

        num_buf[0] = (char)('1' + s_cursor);
        num_buf[1] = '/';
        num_buf[2] = (char)('0' + s_count);
        num_buf[3] = '\0';

        gfx_set_evidence_icon_sprite((REC_BOX_X + 1) * 8, (REC_BOX_Y + 2) * 8, def->icon, 1);
        text_print(REC_BOX_X + 4, REC_BOX_Y + 2, def->name, PAL_BANK_HIGHLIGHT);
        text_print(REC_BOX_X + REC_BOX_W - 5, REC_BOX_Y + 2, num_buf, PAL_BANK_TEXT);
        text_print(REC_BOX_X + 1, REC_BOX_Y + 5, def->desc, PAL_BANK_TEXT);
        text_print(REC_BOX_X + 2, REC_BOX_Y + REC_BOX_H - 1, "< D-PAD >", PAL_BANK_HIGHLIGHT);
    }
}

void evidence_ui_open(RecordUiMode mode)
{
    s_ui_mode = mode;
    if (s_cursor >= s_count) {
        s_cursor = 0;
    }
    sound_play(SFX_BLIP);
    render_record_ui();
}

void evidence_ui_close(void)
{
    if (s_ui_mode != RECORD_MODE_CLOSED) {
        gfx_bg0_clear_rect(REC_BOX_X, REC_BOX_Y, REC_BOX_W, REC_BOX_H);
        gfx_set_evidence_icon_sprite(0, 0, ICON_PLUM_JAR, 0);
        s_ui_mode = RECORD_MODE_CLOSED;
    }
}

int evidence_ui_is_open(void)
{
    return s_ui_mode != RECORD_MODE_CLOSED;
}

int evidence_ui_update(void)
{
    if (s_ui_mode == RECORD_MODE_CLOSED) {
        return -2;
    }

    if (key_hit(KEY_B)) {
        sound_play(SFX_BLIP);
        evidence_ui_close();
        return -2;
    }

    if (s_count > 1) {
        if (key_hit(KEY_RIGHT) || key_hit(KEY_DOWN)) {
            s_cursor = (s_cursor + 1) % s_count;
            sound_play(SFX_BLIP);
            render_record_ui();
        } else if (key_hit(KEY_LEFT) || key_hit(KEY_UP)) {
            s_cursor = (s_cursor + s_count - 1) % s_count;
            sound_play(SFX_BLIP);
            render_record_ui();
        }
    }

    if (s_ui_mode == RECORD_MODE_PRESENT && s_count > 0 && key_hit(KEY_A)) {
        int chosen_ev = s_slots[s_cursor];
        evidence_ui_close();
        return chosen_ev;
    }

    return -1;
}
