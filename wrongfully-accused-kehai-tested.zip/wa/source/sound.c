/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * source/sound.c
 * What this file does: Drives the GBA's DMG PSG square channels (Channel 1 & 2)
 * for typewriter blips, the "OBJECTION!" sting, wrong-present buzz, gavel
 * thud, sanshin Ryukyu pentatonic pluck, and evidence ding.
 * What this file does NOT do: Use DirectSound FIFO or DMA audio.
 */

#include <tonc.h>
#include "sound.h"

/* DMG PSG frequency values: rate = 2048 - (131072 / Hz) */
#define PSG_RATE_C4     1548
#define PSG_RATE_E4     1651
#define PSG_RATE_F4     1673
#define PSG_RATE_G4     1714
#define PSG_RATE_B4     1783
#define PSG_RATE_C5     1798
#define PSG_RATE_E5     1849
#define PSG_RATE_G5     1881
#define PSG_RATE_LOW    900

static SfxId s_active_seq = SFX_NONE;
static int s_seq_timer = 0;

static void play_ch1_tone(u16 rate, u16 duty, u16 env_step, u16 sweep)
{
    REG_SND1SWEEP = sweep;
    REG_SND1CNT   = SSQR_DUTY(duty) | SSQR_IVOL(12) | SSQR_DEC | (env_step << 8);
    REG_SND1FREQ  = SFREQ_RESET | (rate & 0x07FF);
}

static void play_ch2_tone(u16 rate, u16 duty, u16 env_step)
{
    REG_SND2CNT  = SSQR_DUTY(duty) | SSQR_IVOL(11) | SSQR_DEC | (env_step << 8);
    REG_SND2FREQ = SFREQ_RESET | (rate & 0x07FF);
}

void sound_init(void)
{
    REG_SNDSTAT   = SSTAT_ENABLE;
    REG_SNDDMGCNT = SDMG_BUILD_LR(SDMG_SQR1 | SDMG_SQR2, 7);
    REG_SNDDSCNT  = SDS_DMG100;
    s_active_seq  = SFX_NONE;
    s_seq_timer   = 0;
}

void sound_play(SfxId sfx)
{
    switch (sfx) {
    case SFX_BLIP:
        /* Short blip on Channel 2 so it never cuts off a Channel 1 sting */
        play_ch2_tone(PSG_RATE_G4, 2, 1);
        break;

    case SFX_OBJECTION:
        /* Ascending 3-note heroic chord sting on Channel 1 */
        s_active_seq = SFX_OBJECTION;
        s_seq_timer  = 0;
        play_ch1_tone(PSG_RATE_C5, 2, 2, 0x0014);
        break;

    case SFX_WRONG:
        /* Harsh low buzz with downward sweep */
        s_active_seq = SFX_WRONG;
        s_seq_timer  = 0;
        play_ch1_tone(PSG_RATE_LOW, 0, 3, 0x003B);
        break;

    case SFX_GAVEL:
        /* Sharp percussive gavel strike */
        s_active_seq = SFX_NONE;
        play_ch1_tone(1100, 1, 1, 0x002F);
        break;

    case SFX_SANSHIN:
        /* Ryukyu pentatonic pluck (C4 -> E4 -> F4 -> G4 -> B4 -> C5) */
        s_active_seq = SFX_SANSHIN;
        s_seq_timer  = 0;
        play_ch1_tone(PSG_RATE_C4, 1, 2, 0);
        break;

    case SFX_DING:
        /* Two-note evidence collected chime */
        s_active_seq = SFX_DING;
        s_seq_timer  = 0;
        play_ch1_tone(PSG_RATE_E5, 2, 2, 0);
        break;

    case SFX_NONE:
    default:
        break;
    }
}

void sound_update(void)
{
    if (s_active_seq == SFX_NONE) {
        return;
    }

    s_seq_timer++;

    if (s_active_seq == SFX_OBJECTION) {
        if (s_seq_timer == 6) {
            play_ch1_tone(PSG_RATE_E5, 2, 2, 0);
        } else if (s_seq_timer == 12) {
            play_ch1_tone(PSG_RATE_G5, 2, 4, 0);
            s_active_seq = SFX_NONE;
        }
    } else if (s_active_seq == SFX_WRONG) {
        if (s_seq_timer == 10) {
            play_ch1_tone(780, 0, 4, 0);
            s_active_seq = SFX_NONE;
        }
    } else if (s_active_seq == SFX_DING) {
        if (s_seq_timer == 7) {
            play_ch1_tone(PSG_RATE_G5, 2, 3, 0);
            s_active_seq = SFX_NONE;
        }
    } else if (s_active_seq == SFX_SANSHIN) {
        if (s_seq_timer == 10) {
            play_ch1_tone(PSG_RATE_E4, 1, 2, 0);
        } else if (s_seq_timer == 20) {
            play_ch1_tone(PSG_RATE_F4, 1, 2, 0);
        } else if (s_seq_timer == 30) {
            play_ch1_tone(PSG_RATE_G4, 1, 2, 0);
        } else if (s_seq_timer == 40) {
            play_ch1_tone(PSG_RATE_B4, 1, 2, 0);
        } else if (s_seq_timer == 50) {
            play_ch1_tone(PSG_RATE_C5, 1, 4, 0);
            s_active_seq = SFX_NONE;
        }
    }
}
