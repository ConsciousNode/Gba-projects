/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * source/main.c
 * What this file does: Initializes GBA VBlank interrupts and subsystems, owns
 * the global GameContext, and runs the 60 FPS VBlank-synced state machine loop.
 * What this file does NOT do: Busy-wait on REG_VCOUNT, use malloc, or use floats.
 */

#include <tonc.h>
#include "config.h"
#include "game.h"
#include "gfx.h"
#include "text.h"
#include "sound.h"
#include "evidence.h"
#include "script_vm.h"
#include "state_title.h"
#include "state_investigate.h"
#include "state_court.h"
#include "state_verdict.h"

GameContext g_game;

void game_reset_session(void)
{
    g_game.confidence = CONFIDENCE_MAX_PIPS;
    g_game.verdict_is_good = 0;
    evidence_init();
    vm_init();
}

void game_change_state(GameStateId next_state)
{
    g_game.state = next_state;
    switch (next_state) {
    case STATE_TITLE:
        state_title_enter();
        break;
    case STATE_INVESTIGATE:
        state_investigate_enter();
        break;
    case STATE_COURT:
        state_court_enter();
        break;
    case STATE_VERDICT:
        state_verdict_enter();
        break;
    }
}

int main(void)
{
    /* Initialize VBlank interrupt for BIOS VBlankIntrWait() */
    irq_init(NULL);
    irq_add(II_VBLANK, NULL);

    gfx_init();
    text_init();
    sound_init();
    game_reset_session();

    /* Enter initial title screen state and flush initial VRAM/OAM in VBlank */
    game_change_state(STATE_TITLE);
    VBlankIntrWait();
    gfx_vblank_flush();

    REG_DISPCNT = DCNT_MODE0 | DCNT_BG0 | DCNT_BG1 | DCNT_BG2 | DCNT_OBJ | DCNT_OBJ_1D;

    while (1) {
        VBlankIntrWait();
        gfx_vblank_flush();

        key_poll();
        sound_update();
        g_game.frame_counter++;

        switch (g_game.state) {
        case STATE_TITLE:
            state_title_update();
            break;
        case STATE_INVESTIGATE:
            state_investigate_update();
            break;
        case STATE_COURT:
            state_court_update();
            break;
        case STATE_VERDICT:
            state_verdict_update();
            break;
        }
    }

    return 0;
}
