/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * source/state_verdict.c
 * What this file does: Displays the final verdict screen ("CASE 1 CLEAR" for
 * Not Guilty or "GAME OVER" for Guilty) and returns to the title screen when
 * START or A is pressed.
 * What this file does NOT do: Save clear data to SRAM.
 */

#include <tonc.h>
#include "config.h"
#include "game.h"
#include "gfx.h"
#include "text.h"
#include "sound.h"
#include "state_verdict.h"

void state_verdict_enter(void)
{
    gfx_sprites_hide_all();
    gfx_set_portrait(PORTRAIT_NONE);
    gfx_set_bg(BG_ID_VERDICT);
    gfx_bg0_clear();

    gfx_bg0_draw_box(2, 2, 26, 15, PAL_BANK_TEXT);

    if (g_game.verdict_is_good) {
        sound_play(SFX_OBJECTION);
        text_print(5, 4, "VERDICT: NOT GUILTY", PAL_BANK_HIGHLIGHT);
        text_print(8, 7, "CASE 1 CLEAR!", PAL_BANK_HIGHLIGHT);
        text_print(4, 10, "The Scribe's plum theft", PAL_BANK_TEXT);
        text_print(4, 11, "is exposed! Mukou walks", PAL_BANK_TEXT);
        text_print(4, 12, "free to play another day.", PAL_BANK_TEXT);
    } else {
        sound_play(SFX_WRONG);
        text_print(7, 4, "VERDICT: GUILTY", PAL_BANK_HIGHLIGHT);
        text_print(10, 7, "GAME OVER", PAL_BANK_HIGHLIGHT);
        text_print(4, 10, "Sentence: Hand-polish", PAL_BANK_TEXT);
        text_print(4, 11, "10,000 grains of royal", PAL_BANK_TEXT);
        text_print(4, 12, "rice with a silk cloth!", PAL_BANK_TEXT);
    }

    text_print(5, 15, "PRESS START FOR TITLE", PAL_BANK_HIGHLIGHT);
}

void state_verdict_update(void)
{
    if (key_hit(KEY_START) || key_hit(KEY_A)) {
        sound_play(SFX_BLIP);
        game_change_state(STATE_TITLE);
    }
}
