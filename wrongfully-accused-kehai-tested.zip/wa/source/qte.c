/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * source/qte.c
 * What this file does: Implements the "Fukui-san!" Commentary QTE with a
 * button prompt and shrinking 16-tile timer bar on BG0 + OBJ sprite.
 * What this file does NOT do: Deduct Confidence on failure (only returns the
 * scripted fail scene PC).
 */

#include <tonc.h>
#include "qte.h"
#include "gfx.h"
#include "text.h"
#include "sound.h"

#define QTE_BOX_X       3
#define QTE_BOX_Y       3
#define QTE_BOX_W       24
#define QTE_BOX_H       6
#define QTE_BAR_TILES   16

static int s_active = 0;
static QteButton s_button = QTE_BTN_A;
static int s_total_frames = 90;
static int s_frames_left = 90;
static u32 s_success_pc = 0;
static u32 s_fail_pc = 0;

static u16 button_to_key(QteButton btn)
{
    switch (btn) {
    case QTE_BTN_A: return KEY_A;
    case QTE_BTN_B: return KEY_B;
    case QTE_BTN_L: return KEY_L;
    case QTE_BTN_R: return KEY_R;
    }
    return KEY_A;
}

static const char *button_prompt_str(QteButton btn)
{
    switch (btn) {
    case QTE_BTN_A: return "PRESS [A] NOW!";
    case QTE_BTN_B: return "PRESS [B] NOW!";
    case QTE_BTN_L: return "PRESS [L] NOW!";
    case QTE_BTN_R: return "PRESS [R] NOW!";
    }
    return "PRESS [A] NOW!";
}

static void render_qte_box(void)
{
    int i;
    int filled = (s_frames_left * QTE_BAR_TILES + s_total_frames - 1) / s_total_frames;

    gfx_bg0_draw_box(QTE_BOX_X, QTE_BOX_Y, QTE_BOX_W, QTE_BOX_H, PAL_BANK_TEXT);
    text_print(QTE_BOX_X + 2, QTE_BOX_Y + 1, "FUKUI-SAN! QTE!", PAL_BANK_HIGHLIGHT);
    text_print(QTE_BOX_X + 5, QTE_BOX_Y + 2, button_prompt_str(s_button), PAL_BANK_TEXT);

    for (i = 0; i < QTE_BAR_TILES; i++) {
        u16 tid = (i < filled) ? UI_TILE_BAR_FULL : UI_TILE_BAR_EMPTY;
        gfx_bg0_put_tile(QTE_BOX_X + 4 + i, QTE_BOX_Y + 4, tid, PAL_BANK_TEXT);
    }

    gfx_set_qte_sprite((QTE_BOX_X + 1) * 8, (QTE_BOX_Y + 2) * 8, 1);
}

static void clear_qte_box(void)
{
    gfx_bg0_clear_rect(QTE_BOX_X, QTE_BOX_Y, QTE_BOX_W, QTE_BOX_H);
    gfx_set_qte_sprite(0, 0, 0);
    s_active = 0;
}

void qte_start(QteButton button, int total_frames, u32 success_pc, u32 fail_pc)
{
    s_active = 1;
    s_button = button;
    s_total_frames = (total_frames > 0) ? total_frames : 90;
    s_frames_left = s_total_frames;
    s_success_pc = success_pc;
    s_fail_pc = fail_pc;

    sound_play(SFX_DING);
    render_qte_box();
}

int qte_is_active(void)
{
    return s_active;
}

QteResult qte_update(u32 *out_next_pc)
{
    u16 req_key;
    u16 any_action;

    if (!s_active) {
        return QTE_STATE_INACTIVE;
    }

    req_key = button_to_key(s_button);
    any_action = KEY_A | KEY_B | KEY_L | KEY_R;

    if (key_hit(req_key)) {
        clear_qte_box();
        if (out_next_pc) *out_next_pc = s_success_pc;
        return QTE_STATE_WON;
    }

    if (key_hit(any_action & ~req_key)) {
        clear_qte_box();
        if (out_next_pc) *out_next_pc = s_fail_pc;
        return QTE_STATE_LOST;
    }

    s_frames_left--;
    if (s_frames_left <= 0) {
        clear_qte_box();
        if (out_next_pc) *out_next_pc = s_fail_pc;
        return QTE_STATE_LOST;
    }

    render_qte_box();
    return QTE_STATE_RUNNING;
}
