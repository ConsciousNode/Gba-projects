/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * source/state_investigate.c
 * What this file does: Implements the single-location Tea House investigation
 * phase: 3 hotspots selected with a D-pad cursor sprite, R to view the Court
 * Record, and the START menu ("Play sanshin" and "Go to court" once >= 3 of 4
 * evidence items are collected).
 * What this file does NOT do: Reveal the charge before court begins.
 */

#include <tonc.h>
#include "config.h"
#include "game.h"
#include "gfx.h"
#include "text.h"
#include "sound.h"
#include "evidence.h"
#include "script_vm.h"
#include "script_data.h"
#include "state_investigate.h"

typedef struct {
    int x;
    int y;
    int w;
    int h;
    const char *label;
    u32 scene_pc;
} Hotspot;

static const Hotspot s_hotspots[HOTSPOT_COUNT] = {
    {
        HOTSPOT_MERCHANT_X, HOTSPOT_MERCHANT_Y,
        HOTSPOT_MERCHANT_W, HOTSPOT_MERCHANT_H,
        HOTSPOT_MERCHANT_LABEL, SCENE_HOTSPOT_MERCHANT
    },
    {
        HOTSPOT_MUSICIAN_X, HOTSPOT_MUSICIAN_Y,
        HOTSPOT_MUSICIAN_W, HOTSPOT_MUSICIAN_H,
        HOTSPOT_MUSICIAN_LABEL, SCENE_HOTSPOT_MUSICIAN
    },
    {
        HOTSPOT_JAR_X, HOTSPOT_JAR_Y,
        HOTSPOT_JAR_W, HOTSPOT_JAR_H,
        HOTSPOT_JAR_LABEL, SCENE_HOTSPOT_JAR
    }
};

static int s_cursor_x = 112;
static int s_cursor_y = 60;
static int s_menu_open = 0;
static int s_menu_sel = 0;
static int s_hud_drawn = 0;
static int s_last_hover = -2;

static int get_hovered_hotspot(void)
{
    int cx = s_cursor_x + 8;
    int cy = s_cursor_y + 8;
    int i;
    for (i = 0; i < HOTSPOT_COUNT; i++) {
        const Hotspot *h = &s_hotspots[i];
        if (cx >= h->x && cx < h->x + h->w && cy >= h->y && cy < h->y + h->h) {
            return i;
        }
    }
    return -1;
}

static void draw_investigate_hud(int hover_idx)
{
    char ev_buf[12];
    int cnt = evidence_count();

    gfx_bg0_draw_box(0, 0, 30, 3, PAL_BANK_TEXT);
    ev_buf[0] = 'E';
    ev_buf[1] = 'V';
    ev_buf[2] = ':';
    ev_buf[3] = (char)('0' + cnt);
    ev_buf[4] = '/';
    ev_buf[5] = '4';
    ev_buf[6] = '\0';

    text_print(1, 1, ev_buf, PAL_BANK_HIGHLIGHT);
    text_print(9, 1, "R:RECORD START:MENU", PAL_BANK_TEXT);

    gfx_bg0_draw_box(0, 17, 30, 3, PAL_BANK_TEXT);
    if (hover_idx >= 0) {
        text_print(2, 18, s_hotspots[hover_idx].label, PAL_BANK_HIGHLIGHT);
    } else {
        text_print(2, 18, "D-PAD:Move Cursor A:Inspect", PAL_BANK_TEXT);
    }
}

static void draw_start_menu(void)
{
    int can_court = (evidence_count() >= SLICE_REQUIRED_EVIDENCE);

    gfx_bg0_draw_box(4, 5, 22, 7, PAL_BANK_TEXT);
    text_print(6, 5, "INVESTIGATION MENU", PAL_BANK_HIGHLIGHT);

    text_print(
        6, 7,
        (s_menu_sel == 0) ? "> Play sanshin" : "  Play sanshin",
        (s_menu_sel == 0) ? PAL_BANK_HIGHLIGHT : PAL_BANK_TEXT
    );

    if (can_court) {
        text_print(
            6, 9,
            (s_menu_sel == 1) ? "> Go to court!" : "  Go to court!",
            (s_menu_sel == 1) ? PAL_BANK_HIGHLIGHT : PAL_BANK_TEXT
        );
    } else {
        text_print(
            6, 9,
            (s_menu_sel == 1) ? "> Court (Need 3 EV)" : "  Court (Need 3 EV)",
            PAL_BANK_TEXT
        );
    }
}

void state_investigate_enter(void)
{
    gfx_sprites_hide_all();
    gfx_set_bg(BG_ID_TEAHOUSE);
    gfx_set_portrait(PORTRAIT_NONE);
    gfx_bg0_clear();

    s_cursor_x = 112;
    s_cursor_y = 60;
    s_menu_open = 0;
    s_menu_sel = 0;
    s_hud_drawn = 0;
    s_last_hover = -2;

    vm_jump(SCENE_INTRO);
    vm_step();
}

void state_investigate_update(void)
{
    int hover;

    if (vm_get_mode() != VM_MODE_INVESTIGATE) {
        s_hud_drawn = 0;
        gfx_set_cursor_sprite(0, 0, 0);
        vm_step();
        return;
    }

    /* Court Record overlay open */
    if (evidence_ui_is_open()) {
        gfx_set_cursor_sprite(0, 0, 0);
        if (evidence_ui_update() == -2) {
            s_hud_drawn = 0;
        }
        return;
    }

    /* START menu overlay open */
    if (s_menu_open) {
        gfx_set_cursor_sprite(0, 0, 0);
        if (key_hit(KEY_UP) || key_hit(KEY_DOWN)) {
            s_menu_sel ^= 1;
            sound_play(SFX_BLIP);
            draw_start_menu();
        } else if (key_hit(KEY_B) || key_hit(KEY_START)) {
            sound_play(SFX_BLIP);
            s_menu_open = 0;
            gfx_bg0_clear_rect(4, 5, 22, 7);
            s_hud_drawn = 0;
        } else if (key_hit(KEY_A)) {
            if (s_menu_sel == 0) {
                s_menu_open = 0;
                gfx_bg0_clear();
                vm_jump(SCENE_ACTION_SANSHIN);
                vm_step();
            } else {
                if (evidence_count() >= SLICE_REQUIRED_EVIDENCE) {
                    s_menu_open = 0;
                    gfx_bg0_clear();
                    sound_play(SFX_GAVEL);
                    vm_jump(SCENE_ACTION_GO_COURT);
                    vm_step();
                } else {
                    sound_play(SFX_WRONG);
                }
            }
        }
        return;
    }

    /* Free-roam investigation cursor movement */
    if (key_is_down(KEY_LEFT))  s_cursor_x -= 2;
    if (key_is_down(KEY_RIGHT)) s_cursor_x += 2;
    if (key_is_down(KEY_UP))    s_cursor_y -= 2;
    if (key_is_down(KEY_DOWN))  s_cursor_y += 2;

    if (s_cursor_x < 8)   s_cursor_x = 8;
    if (s_cursor_x > 216) s_cursor_x = 216;
    if (s_cursor_y < 24)  s_cursor_y = 24;
    if (s_cursor_y > 116) s_cursor_y = 116;

    gfx_set_cursor_sprite(s_cursor_x, s_cursor_y, 1);

    hover = get_hovered_hotspot();
    if (!s_hud_drawn || hover != s_last_hover) {
        draw_investigate_hud(hover);
        s_hud_drawn = 1;
        s_last_hover = hover;
    }

    if (key_hit(KEY_R)) {
        evidence_ui_open(RECORD_MODE_VIEW);
        return;
    }

    if (key_hit(KEY_START)) {
        s_menu_open = 1;
        s_menu_sel = 0;
        sound_play(SFX_BLIP);
        draw_start_menu();
        return;
    }

    if (key_hit(KEY_A) && hover >= 0) {
        sound_play(SFX_BLIP);
        gfx_set_cursor_sprite(0, 0, 0);
        gfx_bg0_clear();
        vm_jump(s_hotspots[hover].scene_pc);
        vm_step();
    }
}
