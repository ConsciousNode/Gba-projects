```markdown
# Script Authoring Guide (`script/*.wa`)

You do not need to touch C code to write or rewrite cases. All dialogue, portraits, sound effects, investigation hotspots, cross-examinations, and QTEs live in plain-text `.wa` files inside `script/`:
- `script/evidence.wa` — defines the items that can go into the Court Record.
- `script/case1.wa` — defines every scene, line of dialogue, and testimony block.

Whenever you edit a `.wa` file and run `make`, the script compiler (`tools/wacc.py`) automatically checks your script for mistakes, word-wraps every dialogue line to fit the GBA screen (`3 lines × 28 characters`), and regenerates the ROM data.

---

## 1. Defining Evidence (`script/evidence.wa`)

Each evidence item is wrapped in an `evidence <id> ... end` block:

```text
evidence guard_log
  name "Pantry Sign-Out Log"
  desc "Signed at dawn by The Scribe: 'Took 1 Royal Plum for private study.'"
  icon ev_guard_log
end

 * evidence <id>: Internal name used in case1.wa (letters, numbers, and underscores only).
 * name "...": Display title shown in the Court Record (max 22 characters).
 * desc "...": Description shown in the Court Record (auto-wrapped to 3 lines × 28 characters).
 * icon <icon_name>: One of the 16×16 evidence icon sprites (ev_plum_jar, ev_tea_receipt, ev_nori_scrap, ev_guard_log).
2. Case Script Commands (script/case1.wa)
Comments start with # and are ignored by the compiler.
@scene <name> and goto <scene>
Marks the start of a named scene or jumps immediately to another scene.
@scene intro
goto hotspot_merchant

Speaker Dialogue Lines (SPEAKER: text...)
Prints typewriter text in the dialogue box with the speaker's display name from include/config.h.
Valid speakers: MUKOU, MAGISTRATE, SCRIBE, WITNESS, OHTA, FUKUI, NARRATOR.
MUKOU: Another dusty day in Edo. No surname, no coin, and only my sanshin by my side.
NARRATOR: The old musician glares into his cup in silence. Words will not move him.

portrait <character> <expression> (or portrait none)
Changes the 64×64 character bust on BG1.
portrait mukou confident
portrait magistrate shout
portrait scribe smug
portrait witness sweat
portrait ohta neutral
portrait fukui neutral
portrait none

bg <name>
Switches the 240×160 background on BG2 (title, teahouse, court, charge, verdict).
bg teahouse
bg court

sfx <name>
Triggers a Game Boy PSG sound effect (blip, objection, wrong, gavel, sanshin, ding).
sfx gavel
sfx objection

give <evidence_id> and if has <evidence_id> goto <scene>
Adds an item from script/evidence.wa to the player's Court Record, or branches if the player already has it.
if has plum_jar goto jar_repeat
give plum_jar

flag set <name> and if flag <name> goto <scene>
Sets a story flag (up to 32 flags per case) or branches if a flag is already set.
flag set sanshin_played
if flag sanshin_played goto musician_unlock

investigate
Hides the dialogue box and returns control to the player's movable cursor in the investigation room.
MUKOU: Let's keep looking around the tea house.
investigate

charge_reveal "<text>"
Triggers the dramatic Iron Chef-style "TODAY'S CHARGE IS… ALLEZ LAW!" screen in court.
charge_reveal "STEALIN' THE SHOGUN'S IMPERIAL PICKLED PLUM!"

testimony <name> ... end and return_testimony
Defines a 4-statement cross-examination block.
 * Every statement has a press=<scene> branch when the player presses L.
 * Optional revise_flag=<flag_name> revised_text="..." swaps a statement's text once that flag is set.
 * Exactly one statement in the block must have contradicted_by=<evidence_id> success=<scene>.
 * wrong_present=<scene> runs whenever the player presents the wrong item with R → A.
 * Inside any press scene or wrong_present scene, return_testimony returns the player to the active testimony statement (or jumps to @scene no_confidence if Confidence hit 0).
testimony witness_plum_testimony
  statement "1. At noon today, that bard crept into my tea shop with theft in his eyes." press=press_stmt1
  statement "2. He demanded our finest jar and refused to pay a single copper mon!" press=press_stmt2 revise_flag=stmt2_revised revised_text="2. Well, he paid for tea, but he stared greedily at the royal porcelain!"
  statement "3. Nobody touched the royal plum at dawn; the pantry stayed shut till noon!" press=press_stmt3 contradicted_by=guard_log success=court_victory
  statement "4. Therefore, that nameless bard swallowed the Imperial Pickled Plum whole!" press=press_stmt4
  wrong_present=court_wrong_present
end

qte <button> <frames> success=<scene> fail=<scene>
Fires the Ohta-san / Fukui-san Commentary QuickTime Event with a shrinking timer bar (60 frames = 1.0 second; 90 frames = 1.5 seconds). Valid buttons: A, B, L, R.
qte A 90 success=qte_win fail=qte_lose

confidence +1 / confidence -1
Adds or removes Confidence pips (clamped between 0 and 5).
confidence -1
confidence +1

ending good / ending bad
Ends the case and transitions to the Verdict screen (CASE 1 CLEAR! for good, GAME OVER for bad).
ending good
ending bad

3. Complete Tiny Example Scene
@scene hotspot_jar
bg teahouse
if has plum_jar goto jar_already_taken
portrait mukou neutral
NARRATOR: An ornate porcelain jar sits on the table, bearing the Shogun's crest.
MUKOU: Completely empty. Wait a moment... let me sniff the inside of the lid.
portrait mukou confident
MUKOU: It smells of sweet red bean paste, not sour plum brine! I'll take this jar!
sfx ding
give plum_jar
investigate

@scene jar_already_taken
portrait mukou neutral
MUKOU: I already packed the Empty Plum Porcelain. It smells of sweet bean paste.
investigate

4. Reading Compiler Error Messages
When tools/wacc.py finds a problem, it stops the build and prints a plain-English error with the file name and line number:
 * ERROR: case1.wa line 42: scene "witness_lies" is never defined
   * You wrote goto witness_lies (or press=witness_lies), but there is no @scene witness_lies anywhere in case1.wa. Check your spelling.
 * ERROR: case1.wa line 58: evidence "golden_radish" is never defined in evidence.wa
   * You wrote give golden_radish or contradicted_by=golden_radish, but golden_radish hasn't been added to script/evidence.wa yet.
 * ERROR: case1.wa line 19: MUKOU dialogue wraps to 4 lines, which is too long to fit in a 3-line x 28-character box: "..."
   * That single line of dialogue is too long for one GBA text box. Split it into two consecutive MUKOU: lines or trim a few words.
 * ERROR: case1.wa line 180: testimony "witness_plum_testimony" has 0 contradictions (must have exactly 1 statement with contradicted_by)
   * Every testimony block must have 4 statements and exactly 1 statement marked with contradicted_by=<evidence_id> success=<scene>.
