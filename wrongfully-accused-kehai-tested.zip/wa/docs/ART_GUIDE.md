```markdown
# Art & Asset Replacement Guide

All final pixel art is hand-drawn by Kham. The project ships with generated 16-colour indexed PNG placeholders (`tools/make_placeholders.py`) so the ROM builds out of the box and you can replace assets one by one with **zero code changes**.

---

## 1. Transparency Rule (Palette Index 0)

- In every portrait and sprite, **Palette Index 0 is transparent**.
- In the generated placeholder PNGs, Palette Index 0 is set to **bright magenta (`#FF00FF`, RGB `255, 0, 255`)**.
- When `grit` converts a PNG using its matching `.grit` file, Palette Index 0 of the PNG's colour table becomes hardware colour 0 (transparent on GBA).

---

## 2. Complete Asset Table (`graphics/`)

Every asset lives in `graphics/` alongside a `.grit` file of the same name.

### Backgrounds (`240×160` pixels, 4bpp, max 16 colours, BG Palette Bank 3)
| File Name | Dimensions | Max Colours | Purpose |
|---|---|---|---|
| `graphics/bg_title.png` | `240×160` | 16 | Title screen backdrop |
| `graphics/bg_teahouse.png` | `240×160` | 16 | Investigation location (Tea House Street) |
| `graphics/bg_court.png` | `240×160` | 16 | Edo Supreme Courtroom arena |
| `graphics/bg_charge.png` | `240×160` | 16 | Dramatic "TODAY'S CHARGE IS… ALLEZ LAW!" burst screen |
| `graphics/bg_verdict.png` | `240×160` | 16 | Verdict / Case Clear / Game Over backdrop |

### Character Portraits (`64×64` pixels, 4bpp, max 16 colours, BG Palette Bank 2)
| File Name | Dimensions | Max Colours | Character & Expression |
|---|---|---|---|
| `graphics/mukou_neutral.png` | `64×64` | 16 | Mukou — calm / default |
| `graphics/mukou_sweat.png` | `64×64` | 16 | Mukou — nervous / sweating |
| `graphics/mukou_confident.png` | `64×64` | 16 | Mukou — confident / objection |
| `graphics/magistrate_neutral.png` | `64×64` | 16 | The Magistrate — theatrical calm |
| `graphics/magistrate_shout.png` | `64×64` | 16 | The Magistrate — shouting `"ALLEZ LAW!"` |
| `graphics/scribe_neutral.png` | `64×64` | 16 | The Scribe — stern / defensive |
| `graphics/scribe_smug.png` | `64×64` | 16 | The Scribe — smug / condescending |
| `graphics/witness_neutral.png` | `64×64` | 16 | Tea House Shopkeeper — default |
| `graphics/witness_sweat.png` | `64×64` | 16 | Tea House Shopkeeper — panicking |
| `graphics/ohta_neutral.png` | `64×64` | 16 | Ohta-san (play-by-play commentator; also used for Old Musician NPC in slice) |
| `graphics/fukui_neutral.png` | `64×64` | 16 | Fukui-san (colour analyst commentator) |

### Evidence Icons & UI Sprites (`16×16` pixels, 4bpp, max 16 colours, OBJ Palettes)
| File Name | Dimensions | Max Colours | Purpose |
|---|---|---|---|
| `graphics/ev_plum_jar.png` | `16×16` | 16 | Evidence icon: Empty Plum Porcelain |
| `graphics/ev_tea_receipt.png` | `16×16` | 16 | Evidence icon: Tea House Tally |
| `graphics/ev_nori_scrap.png` | `16×16` | 16 | Evidence icon: Bitten Nori Statute |
| `graphics/ev_guard_log.png` | `16×16` | 16 | Evidence icon: Pantry Sign-Out Log |
| `graphics/spr_cursor.png` | `16×16` | 16 | Investigation targeting cursor |
| `graphics/spr_pip_full.png` | `16×16` | 16 | Confidence meter pip (full) |
| `graphics/spr_pip_empty.png` | `16×16` | 16 | Confidence meter pip (empty) |
| `graphics/spr_qte.png` | `16×16` | 16 | Commentary QTE badge icon |

---

## 3. How to Replace a Placeholder with Your Own Art

1. Open or create your replacement image in **Aseprite**, **LibreSprite**, **GraphicsGale**, or **GIMP** at the **exact pixel dimensions** listed above (`240×160` for backgrounds, `64×64` for portraits, `16×16` for icons/sprites).
2. Switch the image mode to **Indexed** (`Sprite -> Color Mode -> Indexed` in Aseprite) with a **maximum of 16 colours** (indices `0` through `15`).
3. Put your transparent backdrop colour in **Palette Index 0** (top-left swatch).
4. Export/save the file over the existing `.png` inside `graphics/` with the **exact same filename** (for example, `graphics/mukou_neutral.png`).
5. Run `make`. The Makefile automatically detects the updated PNG, runs `grit`, and builds your new art into `wrongfully-accused.gba`!
   - *Note:* `tools/make_placeholders.py` is run by `make` with `--if-missing`, so it will **never overwrite** an existing PNG in `graphics/`. If you ever want to regenerate a deleted placeholder, simply delete that PNG and run `make`.

---

## 4. Tips for Drawing Within the GBA's Limits

- **15 Visible Colours + 1 Transparent Slot:** In 4bpp mode (`16` colours per palette bank), index `0` is always transparent. That gives you **15 usable colours** per background, per portrait, and per sprite.
- **Independent Palettes per Portrait & Background:** Only one background (`BG2`, Palette Bank 3) and one portrait (`BG1`, Palette Bank 2) are displayed at a time, and their palettes are uploaded dynamically during VBlank when they appear. That means **`mukou_neutral.png` and `magistrate_shout.png` do NOT have to share the same 16-colour palette**—each portrait PNG can have its own custom 16-colour palette!
- **Keep Bottom 64 Pixels of Backgrounds Quiet:** The dialogue box covers the bottom `240×64` pixels of the screen (`Y = 96..159`), and the `64×64` character portrait sits centered at `X = 88..151, Y = 24..87`. Place your investigation hotspots and key background details between `Y = 24` and `Y = 96`.
- **GBA RGB555 Colour Space:** The GBA uses 15-bit colour (5 bits per channel, values `0..31`). Very subtle 24-bit gradients may band into steps of 8 (`0, 8, 16, 24...`), so crisp pixel clusters and deliberate dithering look best on hardware.
