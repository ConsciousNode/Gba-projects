# Architecture & Extension Guide

## 1. How the Pieces Fit Together

`Wrongfully Accused of Stealin' From the Shogunate` is structured around a strict separation between **scripted case data** (`script/*.wa` compiled into ROM tables by `tools/wacc.py`), **hardware abstraction** (`gfx.c`, `text.c`, `sound.c`), and **four top-level game states** (`state_title.c`, `state_investigate.c`, `state_court.c`, `state_verdict.c`).

### Build Pipeline
```text
script/evidence.wa ──┐
                     ├──> [tools/wacc.py] ──> source/script_data.c + include/script_data.h ──┐
script/case1.wa ─────┘                                                                       │
                                                                                             ├──> [devkitARM gcc + ld + gbafix] ──> wrongfully-accused.gba
graphics/*.png + *.grit ──> [grit] ─────────> build/*.s + build/*.h ─────────────────────────┤
                                                                                             │
source/*.c + include/*.h ────────────────────────────────────────────────────────────────────┘

Runtime State Machine
                     +------------------------+
                     |      STATE_TITLE       |
                     |   (source/state_title) |
                     +-----------+------------+
                                 |
                            [PRESS START]
                                 |
                                 v
                     +------------------------+
                     |   STATE_INVESTIGATE    |
                     | - Intro (3 boxes)      |
                     | - 3 Cursor Hotspots    |
                     | - START Menu:          |
                     |   * Play sanshin       |
                     |   * Go to court (>=3)  |
                     +-----------+------------+
                                 |
                           [Go to court]
                                 |
                                 v
                     +------------------------+
                     |      STATE_COURT       |
                     | - Charge Reveal        |
                     |   ("ALLEZ LAW!")       |
                     | - 4-Stmt Testimony     |
                     | - Cross-Exam (L / R)   |
                     | - "Fukui-san!" QTE     |
                     +-----+------------+-----+
                           |            |
        [Correct Evidence  |            |  [Confidence == 0]
         Presented on      |            |  (@scene no_confidence
         Contradiction]    |            |   -> ending bad)
        (ending good)      |            |
                           v            v
                     +------------------------+
                     |     STATE_VERDICT      |
                     | - Good: "CASE 1 CLEAR" |
                     | - Bad:  "GAME OVER"    |
                     +-----------+------------+
                                 |
                            [PRESS START]
                                 |
                                 +-----> (Back to STATE_TITLE)

Hardware Memory Map (Mode 0, 4bpp)
| Layer / Resource | GBA Hardware Region | Purpose |
|---|---|---|
| BG0 (Priority 0) | CBB 0 (0x06000000), SBB 28 (0x0600E000), Pal Banks 0–1 | 8×8 ASCII font (32..126), dialogue boxes, menus, Court Record modal, QTE bar |
| BG1 (Priority 1) | CBB 1 (0x06004000), SBB 29 (0x0600E800), Pal Bank 2 | 64×64 character bust/portrait (8×8 flat tiles) |
| BG2 (Priority 2) | CBB 2 (0x06008000), SBB 30 (0x0600F000), Pal Bank 3 | 240×160 location / courtroom background |
| OBJ Sprites (1D) | CBB 4 (0x06010000), OAM (0x07000000), OBJ Pal Banks 0–7 | Cursor (OAM 0), QTE icon (OAM 1), Evidence icon (OAM 2), 5 Confidence pips (OAM 3..7) |
All changes to BG0 tiles, BG1 portraits, BG2 backgrounds, and sprites are staged in RAM (s_bg0_shadow, s_oam_shadow, and dirty flags in source/gfx.c) and copied to VRAM/OAM exclusively inside gfx_vblank_flush() immediately after VBlankIntrWait().
2. Step-by-Step Extension Recipes
Recipe 1: How to Add a Second Case
 * Create the script file: Create script/case2.wa using the same commands as script/case1.wa (starting with @scene case2_intro).
 * Concatenate or pass multiple case files to wacc.py:
   * In Makefile, add $(CURDIR)/script/case2.wa to SCRIPT_WA.
   * In tools/wacc.py, allow parse_case_file to read a list of .wa files into the same scenes and instructions tables (or append case2.wa right below case1.wa).
 * Add current_case to GameContext:
   * In include/game.h, add int current_case; to GameContext.
   * In source/state_verdict.c, when g_game.verdict_is_good is true and the player presses START, increment g_game.current_case and transition to STATE_INVESTIGATE (jumping to SCENE_CASE2_INTRO) instead of returning immediately to STATE_TITLE.
Recipe 2: How to Add a New Investigation Location
 * Add the background art:
   * Place graphics/bg_market.png (240×160, max 16 colours) and copy graphics/bg_teahouse.grit to graphics/bg_market.grit.
 * Register the background ID:
   * Add BG_ID_MARKET to BgId in include/gfx.h.
   * In source/gfx.c, add #include "bg_market.h" and add [BG_ID_MARKET] = { bg_marketTiles, bg_marketTilesLen, bg_marketMap, bg_marketMapLen, bg_marketPal, bg_marketPalLen } to s_bg_assets.
   * In tools/wacc.py, add "market": "BG_ID_MARKET" to VALID_BGS.
 * Define the location's hotspots:
   * In source/state_investigate.c, turn s_hotspots into a 2D array indexed by current_location_id (or switch hotspot tables based on which location is active), and add a "Move" option to the START menu to travel between locations.
Recipe 3: How to Add a New Character and Their Portraits
 * Add the display name:
   * In include/config.h, add #define NAME_DAIMYO "LORD DAIMYO".
 * Register the speaker in the script VM and compiler:
   * Add SPEAKER_DAIMYO to SpeakerId in include/script_vm.h and map it to NAME_DAIMYO in speaker_id_to_name() inside source/script_vm.c.
   * Add "DAIMYO": "SPEAKER_DAIMYO" to VALID_SPEAKERS in tools/wacc.py.
 * Add the 64×64 portrait PNGs:
   * Save graphics/daimyo_neutral.png (64×64, max 16 colours, index 0 transparent) and copy graphics/mukou_neutral.grit to graphics/daimyo_neutral.grit.
   * Add PORTRAIT_DAIMYO_NEUTRAL to PortraitId in include/gfx.h, include "daimyo_neutral.h" in source/gfx.c, and add its entry to s_portrait_assets.
   * Add ("daimyo", "neutral"): "PORTRAIT_DAIMYO_NEUTRAL" to VALID_PORTRAITS in tools/wacc.py.
 * Use in .wa scripts:
   portrait daimyo neutral
DAIMYO: Who dares question my pickled radish tax?!

Recipe 4: How to Add a New Evidence Item
 * If reusing an existing icon:
   * Simply add a new evidence <id> ... end block to script/evidence.wa! The Court Record already holds up to 16 items (COURT_RECORD_MAX_SLOTS), and tools/wacc.py automatically updates EVIDENCE_COUNT and generates #define EV_<ID>.
 * If adding a brand-new 16×16 icon sprite:
   * Save graphics/ev_nohkan.png (16×16, max 16 colours) and copy graphics/ev_plum_jar.grit to graphics/ev_nohkan.grit.
   * Add ICON_NOHKAN before ICON_COUNT in EvidenceIconId (include/gfx.h).
   * In source/gfx.c, #include "ev_nohkan.h" and add its entry to s_ev_icon_assets.
   * In tools/wacc.py, add "ev_nohkan": "ICON_NOHKAN" to VALID_ICONS.
Recipe 5: Where Saving Would Go Later (SRAM Design — Not Implemented in Slice)
GBA flash carts and cartridges provide 32 KB of byte-addressed battery-backed SRAM at 0x0E000000 (sram_mem in libtonc).
 * Hardware constraint: SRAM is an 8-bit bus (volatile u8 *). You must read and write SRAM one byte at a time with a simple for loop—never use memcpy, memcpy16, memcpy32, or struct assignment directly on 0x0E000000.
 * Where to put it: Create source/save.c and include/save.h with save_write_slot(int slot) and save_read_slot(int slot), triggered from a "Save" option in the Investigation START menu and a "Continue" option on the Title screen.
 * Exact state to store (32 bytes per slot):
   * u8 magic[4] — "WA01" header to detect initialized SRAM.
   * u8 case_id — which case (0..5) the player is on.
   * u8 state_id — STATE_INVESTIGATE or STATE_COURT.
   * u16 script_pc — current scene entry PC (s_pc in source/script_vm.c).
   * u8 confidence — current Confidence pips (1..5).
   * u8 evidence_count and s8 evidence_slots[16] — the player's Court Record (source/evidence.c).
   * u32 flags_bitmask — the 32 story flags (s_flags in source/script_vm.c).
   * u16 checksum — simple 16-bit additive/XOR checksum over bytes 0..29 to catch corrupted saves.
