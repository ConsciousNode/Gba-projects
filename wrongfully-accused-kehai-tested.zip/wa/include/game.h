/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/game.h
 * What this file does: Declares the top-level game state enum, static global
 * runtime context, and state transition functions.
 * What this file does NOT do: Implement individual state logic or rendering.
 */

#ifndef GAME_H
#define GAME_H

#include <tonc.h>
#include "config.h"

typedef enum {
    STATE_TITLE = 0,
    STATE_INVESTIGATE,
    STATE_COURT,
    STATE_VERDICT
} GameStateId;

typedef struct {
    GameStateId state;
    int confidence;
    int verdict_is_good;
    u32 frame_counter;
} GameContext;

extern GameContext g_game;

void game_reset_session(void);
void game_change_state(GameStateId next_state);

#endif /* GAME_H */
