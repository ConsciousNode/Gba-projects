/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/config.h
 * What this file does: Centralizes character display names, gameplay constants,
 * hardware screen dimensions, and investigation hotspot rectangles.
 * What this file does NOT do: Hold mutable runtime state or hardware logic.
 */

#ifndef CONFIG_H
#define CONFIG_H

/* Display dimensions (Game Boy Advance LCD) */
#define SCREEN_WIDTH            240
#define SCREEN_HEIGHT           160
#define TILE_SIZE               8

/* Dialogue box geometry (in 8x8 tile coordinates on BG0) */
#define BOX_TILE_X              0
#define BOX_TILE_Y              12
#define BOX_TILE_W              30
#define BOX_TILE_H              8
#define TEXT_LINE_MAX_CHARS     28
#define TEXT_BOX_MAX_LINES      3

/* Typewriter speed: frames per character (2 = 30 chars/sec at 60 FPS) */
#define TYPEWRITER_FRAMES_PER_CHAR 2

/* Courtroom & Court Record limits */
#define COURT_RECORD_MAX_SLOTS  16
#define SLICE_REQUIRED_EVIDENCE 3
#define CONFIDENCE_MAX_PIPS     5

/* Character display names (edit here to rename across the whole game) */
#define NAME_NARRATOR           ""
#define NAME_MUKOU              "MUKOU"
#define NAME_MAGISTRATE         "MAGISTRATE"
#define NAME_SCRIBE             "THE SCRIBE"
#define NAME_WITNESS            "SHOPKEEPER"
#define NAME_OHTA               "OHTA-SAN"
#define NAME_FUKUI              "FUKUI-SAN"

/* Investigation hotspot bounding boxes (in pixels on 240x160 tea house bg) */
#define HOTSPOT_COUNT           3

#define HOTSPOT_MERCHANT_X      32
#define HOTSPOT_MERCHANT_Y      40
#define HOTSPOT_MERCHANT_W      32
#define HOTSPOT_MERCHANT_H      40
#define HOTSPOT_MERCHANT_LABEL  "Talk: Shopkeeper"

#define HOTSPOT_MUSICIAN_X      104
#define HOTSPOT_MUSICIAN_Y      40
#define HOTSPOT_MUSICIAN_W      32
#define HOTSPOT_MUSICIAN_H      40
#define HOTSPOT_MUSICIAN_LABEL  "Talk: Old Musician"

#define HOTSPOT_JAR_X           176
#define HOTSPOT_JAR_Y           48
#define HOTSPOT_JAR_W           32
#define HOTSPOT_JAR_H           32
#define HOTSPOT_JAR_LABEL       "Inspect: Royal Jar"

#endif /* CONFIG_H */
