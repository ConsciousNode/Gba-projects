/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/script_vm.h
 * What this file does: Declares bytecode structures, speaker/opcode enums, and
 * the script virtual machine used by investigation and court states.
 * What this file does NOT do: Parse text files at runtime (tools/wacc.py compiles
 * .wa files into static const tables in ROM).
 */

#ifndef SCRIPT_VM_H
#define SCRIPT_VM_H

#include <tonc.h>
#include "gfx.h"
#include "sound.h"
#include "qte.h"

typedef enum {
    SPEAKER_NARRATOR = 0,
    SPEAKER_MUKOU,
    SPEAKER_MAGISTRATE,
    SPEAKER_SCRIBE,
    SPEAKER_WITNESS,
    SPEAKER_OHTA,
    SPEAKER_FUKUI
} SpeakerId;

typedef enum {
    OP_SAY = 0,
    OP_PORTRAIT,
    OP_BG,
    OP_SFX,
    OP_GIVE,
    OP_FLAG_SET,
    OP_IF_HAS_GOTO,
    OP_IF_FLAG_GOTO,
    OP_GOTO,
    OP_CONFIDENCE,
    OP_QTE,
    OP_CHARGE_REVEAL,
    OP_TESTIMONY,
    OP_INVESTIGATE,
    OP_RETURN_TESTIMONY,
    OP_ENDING
} ScriptOpcode;

typedef struct {
    const char *name;
    const char *desc;
    EvidenceIconId icon;
} EvidenceDef;

typedef struct {
    const char *text;
    const char *revised_text;
    u32 press_pc;
    int contradicted_by_ev;
    u32 success_pc;
    int revise_flag_id;
} StatementDef;

typedef struct {
    u32 wrong_present_pc;
    StatementDef statements[4];
} TestimonyDef;

typedef struct {
    ScriptOpcode op;
    int arg1;
    int arg2;
    int arg3;
    int arg4;
    const char *text;
} ScriptInsn;

typedef enum {
    VM_MODE_IDLE = 0,
    VM_MODE_DIALOGUE,
    VM_MODE_INVESTIGATE,
    VM_MODE_CHARGE_REVEAL,
    VM_MODE_TESTIMONY,
    VM_MODE_QTE
} VmMode;

void vm_init(void);
void vm_jump(u32 target_pc);
void vm_step(void);

VmMode vm_get_mode(void);
void   vm_resume_from_charge_reveal(void);

int  vm_get_flag(int flag_id);
void vm_set_flag(int flag_id, int value);

int  vm_get_active_testimony_id(void);
int  vm_get_active_stmt_index(void);
void vm_set_active_stmt_index(int stmt_idx);
const char *vm_get_statement_text(int testimony_id, int stmt_idx);
const char *vm_get_charge_text(void);

#endif /* SCRIPT_VM_H */
