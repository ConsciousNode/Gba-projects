/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/sound.h
 * What this file does: Declares PSG (DMG square wave) sound effect triggers
 * and frame-level multi-note sequence updates.
 * What this file does NOT do: Play DirectSound PCM samples or background music.
 */

#ifndef SOUND_H
#define SOUND_H

#include <tonc.h>

typedef enum {
    SFX_NONE = 0,
    SFX_BLIP,
    SFX_OBJECTION,
    SFX_WRONG,
    SFX_GAVEL,
    SFX_SANSHIN,
    SFX_DING
} SfxId;

void sound_init(void);
void sound_play(SfxId sfx);
void sound_update(void);

#endif /* SOUND_H */
