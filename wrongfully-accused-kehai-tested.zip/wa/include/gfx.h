/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/gfx.h
 * What this file does: Declares Mode 0 background, portrait, and OAM shadow
 * buffer functions, ensuring all VRAM/OAM writes occur exclusively in VBlank.
 * What this file does NOT do: Draw text strings or decode PNGs at runtime.
 */

#ifndef GFX_H
#define GFX_H

#include <tonc.h>

/* Background IDs matching tools/wacc.py */
typedef enum {
    BG_ID_NONE = 0,
    BG_ID_TITLE,
    BG_ID_TEAHOUSE,
    BG_ID_COURT,
    BG_ID_CHARGE,
    BG_ID_VERDICT
} BgId;

/* Portrait IDs matching tools/wacc.py */
typedef enum {
    PORTRAIT_NONE = 0,
    PORTRAIT_MUKOU_NEUTRAL,
    PORTRAIT_MUKOU_SWEAT,
    PORTRAIT_MUKOU_CONFIDENT,
    PORTRAIT_MAGISTRATE_NEUTRAL,
    PORTRAIT_MAGISTRATE_SHOUT,
    PORTRAIT_SCRIBE_NEUTRAL,
    PORTRAIT_SCRIBE_SMUG,
    PORTRAIT_WITNESS_NEUTRAL,
    PORTRAIT_WITNESS_SWEAT,
    PORTRAIT_OHTA_NEUTRAL,
    PORTRAIT_FUKUI_NEUTRAL
} PortraitId;

/* Evidence icon IDs matching tools/wacc.py */
typedef enum {
    ICON_PLUM_JAR = 0,
    ICON_TEA_RECEIPT,
    ICON_NORI_SCRAP,
    ICON_GUARD_LOG,
    ICON_COUNT
} EvidenceIconId;

/* VRAM layout constants (Mode 0) */
#define BG0_CBB                 0
#define BG0_SBB                 28
#define BG1_CBB                 1
#define BG1_SBB                 29
#define BG2_CBB                 2
#define BG2_SBB                 30

/* BG Palette banks (16 colours each) */
#define PAL_BANK_TEXT           0
#define PAL_BANK_HIGHLIGHT      1
#define PAL_BANK_PORTRAIT       2
#define PAL_BANK_BG             3

/* Fixed OAM sprite indices */
#define OAM_IDX_CURSOR          0
#define OAM_IDX_QTE             1
#define OAM_IDX_EVIDENCE_ICON   2
#define OAM_IDX_PIP_BASE        3   /* Uses indices 3..7 (5 pips) */

void gfx_init(void);
void gfx_vblank_flush(void);

void gfx_set_bg(BgId bg_id);
void gfx_set_portrait(PortraitId portrait_id);

/* BG0 tilemap shadow manipulation (flushed to SBB 28 during VBlank) */
void gfx_bg0_clear(void);
void gfx_bg0_clear_rect(int tx, int ty, int tw, int th);
void gfx_bg0_put_tile(int tx, int ty, u16 tile_id, u16 pal_bank);
void gfx_bg0_draw_box(int tx, int ty, int tw, int th, u16 pal_bank);

/* OBJ sprite helpers (write to g_oam_shadow; flushed to OAM during VBlank) */
void gfx_sprites_hide_all(void);
void gfx_set_cursor_sprite(int x, int y, int visible);
void gfx_set_qte_sprite(int x, int y, int visible);
void gfx_set_evidence_icon_sprite(int x, int y, EvidenceIconId icon, int visible);
void gfx_set_confidence_pips(int current_pips, int max_pips, int visible);

#endif /* GFX_H */
