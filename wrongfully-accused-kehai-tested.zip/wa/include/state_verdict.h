/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/state_verdict.h
 * What this file does: Declares enter and per-frame update hooks for the
 * verdict screen ("CASE 1 CLEAR" or "GAME OVER", returning to title).
 * What this file does NOT do: Run script bytecode.
 */

#ifndef STATE_VERDICT_H
#define STATE_VERDICT_H

void state_verdict_enter(void);
void state_verdict_update(void);

#endif /* STATE_VERDICT_H */
