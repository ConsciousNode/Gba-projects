/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/evidence.h
 * What this file does: Declares the 16-slot Court Record inventory and the
 * modal Court Record UI (used both to browse evidence with R in investigation
 * and to Present evidence with R->A during cross-examination).
 * What this file does NOT do: Define the evidence text (see script/evidence.wa).
 */

#ifndef EVIDENCE_H
#define EVIDENCE_H

#include <tonc.h>
#include "config.h"

typedef enum {
    RECORD_MODE_CLOSED = 0,
    RECORD_MODE_VIEW,
    RECORD_MODE_PRESENT
} RecordUiMode;

void evidence_init(void);
int  evidence_give(int ev_id);
int  evidence_has(int ev_id);
int  evidence_count(void);
int  evidence_get_slot(int index);

/* Modal UI control */
void evidence_ui_open(RecordUiMode mode);
void evidence_ui_close(void);
int  evidence_ui_is_open(void);

/* Updates UI; returns >= 0 if player pressed A in RECORD_MODE_PRESENT,
 * -2 if closed with B, or -1 while still browsing. */
int  evidence_ui_update(void);

#endif /* EVIDENCE_H */
