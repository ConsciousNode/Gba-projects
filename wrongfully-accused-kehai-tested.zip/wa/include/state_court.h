/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/state_court.h
 * What this file does: Declares enter and per-frame update hooks for the
 * courtroom phase (charge reveal, testimony, Press/Present, QTE, Confidence).
 * What this file does NOT do: Manage free-roam cursor investigation.
 */

#ifndef STATE_COURT_H
#define STATE_COURT_H

void state_court_enter(void);
void state_court_update(void);

#endif /* STATE_COURT_H */
