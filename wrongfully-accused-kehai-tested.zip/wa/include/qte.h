/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/qte.h
 * What this file does: Declares the "Fukui-san!" Commentary QuickTime Event
 * (button prompt + shrinking timer bar on BG0/OBJ).
 * What this file does NOT do: Implement multi-button rhythm or mash QTE variants.
 */

#ifndef QTE_H
#define QTE_H

#include <tonc.h>

typedef enum {
    QTE_BTN_A = 0,
    QTE_BTN_B,
    QTE_BTN_L,
    QTE_BTN_R
} QteButton;

typedef enum {
    QTE_STATE_INACTIVE = 0,
    QTE_STATE_RUNNING,
    QTE_STATE_WON,
    QTE_STATE_LOST
} QteResult;

void qte_start(QteButton button, int total_frames, u32 success_pc, u32 fail_pc);
int  qte_is_active(void);
QteResult qte_update(u32 *out_next_pc);

#endif /* QTE_H */
