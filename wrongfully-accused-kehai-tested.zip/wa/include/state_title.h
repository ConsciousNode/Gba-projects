/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/state_title.h
 * What this file does: Declares enter and per-frame update hooks for the title
 * screen state.
 * What this file does NOT do: Manage gameplay or investigation logic.
 */

#ifndef STATE_TITLE_H
#define STATE_TITLE_H

void state_title_enter(void);
void state_title_update(void);

#endif /* STATE_TITLE_H */
