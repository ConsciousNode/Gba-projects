/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/text.h
 * What this file does: Declares the 8x8 ASCII bitmap font loader, direct BG0
 * string drawing helpers, and the typewriter dialogue box engine.
 * What this file does NOT do: Perform runtime word-wrapping (tools/wacc.py
 * wraps all script lines at compile time).
 */

#ifndef TEXT_H
#define TEXT_H

#include <tonc.h>

/* Tile indices in CBB 0 reserved for UI and font */
#define UI_TILE_TRANSPARENT     0
#define UI_TILE_BOX_FILL        1
#define UI_TILE_BOX_BORDER_H    2
#define UI_TILE_BOX_BORDER_V    3
#define UI_TILE_BOX_CORNER      4
#define UI_TILE_BAR_FULL        5
#define UI_TILE_BAR_EMPTY       6
#define FONT_ASCII_BASE_TILE    32  /* ASCII 32..126 map directly to tiles 32..126 */

void text_init(void);

/* Immediate string rendering onto BG0 shadow tilemap */
void text_print(int tx, int ty, const char *str, u16 pal_bank);

/* Typewriter dialogue box functions */
void text_box_start(const char *speaker_name, const char *wrapped_text);
void text_box_hide(void);
void text_box_update(void);
int  text_box_is_typing(void);
void text_box_finish_line(void);

#endif /* TEXT_H */
