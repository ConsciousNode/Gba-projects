/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
 * SPDX-License-Identifier: MIT
 *
 * include/state_investigate.h
 * What this file does: Declares enter and per-frame update hooks for the
 * single-location investigation state (cursor, 3 hotspots, START menu).
 * What this file does NOT do: Run courtroom cross-examinations.
 */

#ifndef STATE_INVESTIGATE_H
#define STATE_INVESTIGATE_H

void state_investigate_enter(void);
void state_investigate_update(void);

#endif /* STATE_INVESTIGATE_H */
