#!/usr/bin/env python3
# Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
# SPDX-License-Identifier: MIT
#
# tools/make_placeholders.py
# Generates 16-colour indexed PNG placeholders and matching .grit files for
# Wrongfully Accused of Stealin' From the Shogunate using only the Python 3
# standard library (struct, zlib, os, sys). Does not overwrite existing PNGs
# when invoked with --if-missing.

import os
import struct
import sys
import zlib

TRANSPARENT_RGB = (255, 0, 255)  # Palette index 0: Magenta (#FF00FF)

# Tiny 4x5 uppercase/symbol bitmap font (each row is 4 bits, 5 rows per glyph)
MINI_FONT = {
    'A': [0b0110, 0b1001, 0b1111, 0b1001, 0b1001],
    'B': [0b1110, 0b1001, 0b1110, 0b1001, 0b1110],
    'C': [0b0111, 0b1000, 0b1000, 0b1000, 0b0111],
    'D': [0b1110, 0b1001, 0b1001, 0b1001, 0b1110],
    'E': [0b1111, 0b1000, 0b1110, 0b1000, 0b1111],
    'F': [0b1111, 0b1000, 0b1110, 0b1000, 0b1000],
    'G': [0b0111, 0b1000, 0b1011, 0b1001, 0b0111],
    'H': [0b1001, 0b1001, 0b1111, 0b1001, 0b1001],
    'I': [0b1110, 0b0100, 0b0100, 0b0100, 0b1110],
    'J': [0b0011, 0b0001, 0b0001, 0b1001, 0b0110],
    'K': [0b1001, 0b1010, 0b1100, 0b1010, 0b1001],
    'L': [0b1000, 0b1000, 0b1000, 0b1000, 0b1111],
    'M': [0b1001, 0b1111, 0b1111, 0b1001, 0b1001],
    'N': [0b1001, 0b1101, 0b1011, 0b1001, 0b1001],
    'O': [0b0110, 0b1001, 0b1001, 0b1001, 0b0110],
    'P': [0b1110, 0b1001, 0b1110, 0b1000, 0b1000],
    'Q': [0b0110, 0b1001, 0b1001, 0b0110, 0b0011],
    'R': [0b1110, 0b1001, 0b1110, 0b1010, 0b1001],
    'S': [0b0111, 0b1000, 0b0110, 0b0001, 0b1110],
    'T': [0b1111, 0b0100, 0b0100, 0b0100, 0b0100],
    'U': [0b1001, 0b1001, 0b1001, 0b1001, 0b0110],
    'V': [0b1001, 0b1001, 0b1001, 0b0110, 0b0110],
    'W': [0b1001, 0b1001, 0b1111, 0b1111, 0b1001],
    'X': [0b1001, 0b0110, 0b0110, 0b1001, 0b1001],
    'Y': [0b1001, 0b1001, 0b0110, 0b0100, 0b0100],
    'Z': [0b1111, 0b0010, 0b0100, 0b1000, 0b1111],
    '0': [0b0110, 0b1001, 0b1001, 0b1001, 0b0110],
    '1': [0b0100, 0b1100, 0b0100, 0b0100, 0b1110],
    '2': [0b1110, 0b0001, 0b0110, 0b1000, 0b1111],
    '3': [0b1110, 0b0001, 0b0110, 0b0001, 0b1110],
    '_': [0b0000, 0b0000, 0b0000, 0b0000, 0b1111],
    '-': [0b0000, 0b0000, 0b1111, 0b0000, 0b0000],
    '!': [0b0100, 0b0100, 0b0100, 0b0000, 0b0100],
    ' ': [0b0000, 0b0000, 0b0000, 0b0000, 0b0000],
}


def png_chunk(chunk_type, data):
    crc = zlib.crc32(chunk_type + data) & 0xFFFFFFFF
    return struct.pack(">I", len(data)) + chunk_type + data + struct.pack(">I", crc)


def write_indexed_png(path, width, height, palette, pixels):
    """Write an 8-bit indexed PNG with exactly 16 palette entries (0..15)."""
    assert len(palette) <= 16
    padded_pal = list(palette) + [(0, 0, 0)] * (16 - len(palette))
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 3, 0, 0, 0)
    plte = b"".join(struct.pack("BBB", r, g, b) for (r, g, b) in padded_pal)

    raw_rows = bytearray()
    for y in range(height):
        raw_rows.append(0)  # Filter type 0 (None)
        row = pixels[y]
        for x in range(width):
            raw_rows.append(row[x] & 0x0F)

    idat = zlib.compress(bytes(raw_rows), 9)
    png_bytes = (
        b"\x89PNG\r\n\x1a\n"
        + png_chunk(b"IHDR", ihdr)
        + png_chunk(b"PLTE", plte)
        + png_chunk(b"IDAT", idat)
        + png_chunk(b"IEND", b"")
    )
    with open(path, "wb") as f:
        f.write(png_bytes)


def make_canvas(width, height, fill_idx=0):
    return [[fill_idx for _ in range(width)] for _ in range(height)]


def draw_rect(canvas, x0, y0, w, h, color_idx, outline_idx=None):
    height = len(canvas)
    width = len(canvas[0])
    for y in range(max(0, y0), min(height, y0 + h)):
        for x in range(max(0, x0), min(width, x0 + w)):
            if outline_idx is not None and (
                x == x0 or x == x0 + w - 1 or y == y0 or y == y0 + h - 1
            ):
                canvas[y][x] = outline_idx
            else:
                canvas[y][x] = color_idx


def draw_text(canvas, x0, y0, text, color_idx, scale=1):
    height = len(canvas)
    width = len(canvas[0])
    cx = x0
    for ch in text.upper():
        glyph = MINI_FONT.get(ch, MINI_FONT[' '])
        for gy, row_bits in enumerate(glyph):
            for gx in range(4):
                if (row_bits >> (3 - gx)) & 1:
                    for sy in range(scale):
                        for sx in range(scale):
                            py = y0 + gy * scale + sy
                            px = cx + gx * scale + sx
                            if 0 <= py < height and 0 <= px < width:
                                canvas[py][px] = color_idx
        cx += 5 * scale


def write_grit(path, content):
    with open(path, "w", encoding="utf-8") as f:
        f.write(content.strip() + "\n")


def generate_backgrounds(gfx_dir, if_missing=False):
    bg_grit = """# 240x160 4bpp tiled background with 16-colour palette
-gt
-gB4
-mRt
-mLs
-pn16
"""
    bgs = [
        (
            "bg_title",
            "WRONGFULLY ACCUSED",
            "STEALIN FROM THE SHOGUNATE",
            [
                TRANSPARENT_RGB,
                (24, 20, 37),    # 1 deep indigo sky
                (48, 36, 66),    # 2 roof shadow
                (140, 35, 35),   # 3 crimson banner
                (212, 175, 55),  # 4 gold trim
                (245, 236, 215), # 5 cream text
                (90, 62, 40),    # 6 wood pillar
                (180, 140, 80),  # 7 tatami tan
            ],
        ),
        (
            "bg_teahouse",
            "TEA HOUSE STREET",
            "D-PAD MOVE   A INSPECT",
            [
                TRANSPARENT_RGB,
                (36, 52, 42),    # 1 bamboo dusk
                (68, 92, 62),    # 2 moss green
                (130, 82, 46),   # 3 cedar beam
                (198, 156, 109), # 4 paper lantern warm
                (242, 232, 208), # 5 shoji cream
                (176, 48, 40),   # 6 noren red
                (85, 55, 32),    # 7 cobblestone
            ],
        ),
        (
            "bg_court",
            "SHOGUNATE COURT",
            "IRON MAGISTRATE ARENA",
            [
                TRANSPARENT_RGB,
                (32, 22, 44),    # 1 courtroom shadow
                (76, 36, 58),    # 2 velvet drape
                (132, 88, 44),   # 3 witness stand oak
                (216, 172, 62),  # 4 kaga gold
                (244, 238, 222), # 5 highlight
                (164, 38, 44),   # 6 shogunate crest red
                (58, 48, 72),    # 7 stone floor
            ],
        ),
        (
            "bg_charge",
            "TODAYS CHARGE IS",
            "ALLEZ LAW!",
            [
                TRANSPARENT_RGB,
                (20, 12, 18),    # 1 dramatic black-red
                (120, 18, 24),   # 2 burst red
                (200, 48, 28),   # 3 flame orange
                (244, 208, 64),  # 4 gold flash
                (252, 248, 236), # 5 white hot
                (80, 20, 28),    # 6 dark stripe
                (160, 120, 40),  # 7 brass frame
            ],
        ),
        (
            "bg_verdict",
            "SHOGUNATE VERDICT",
            "JUDGMENT RENDERED",
            [
                TRANSPARENT_RGB,
                (22, 28, 44),    # 1 night slate
                (44, 62, 92),    # 2 indigo border
                (188, 152, 64),  # 3 gold seal
                (244, 240, 228), # 4 scroll paper
                (148, 36, 36),   # 5 stamp vermilion
                (72, 88, 112),   # 6 pillar blue
                (110, 80, 50),   # 7 wood trim
            ],
        ),
    ]

    for name, title_line, sub_line, pal in bgs:
        png_path = os.path.join(gfx_dir, f"{name}.png")
        grit_path = os.path.join(gfx_dir, f"{name}.grit")
        write_grit(grit_path, bg_grit)
        if if_missing and os.path.exists(png_path):
            continue

        c = make_canvas(240, 160, fill_idx=1)
        # Decorative architectural bands (aligned to 8x8 tiles to keep tile count low)
        draw_rect(c, 0, 0, 240, 24, 2, outline_idx=4)
        draw_rect(c, 0, 88, 240, 72, 7, outline_idx=6)
        draw_rect(c, 8, 24, 16, 72, 6, outline_idx=4)
        draw_rect(c, 216, 24, 16, 72, 6, outline_idx=4)

        if name == "bg_teahouse":
            # Draw 3 visual hotspot markers matching investigation coordinates:
            # 1: Tea Merchant (x=44, y=56), 2: Old Musician (x=120, y=56), 3: Plum Jar Table (x=192, y=64)
            draw_rect(c, 32, 40, 32, 40, 6, outline_idx=5)
            draw_text(c, 37, 52, "NPC1", 5, scale=1)
            draw_rect(c, 104, 40, 32, 40, 2, outline_idx=5)
            draw_text(c, 109, 52, "NPC2", 5, scale=1)
            draw_rect(c, 176, 48, 32, 32, 3, outline_idx=4)
            draw_text(c, 184, 58, "JAR", 5, scale=1)
        elif name == "bg_charge":
            draw_rect(c, 24, 32, 192, 48, 2, outline_idx=4)
        else:
            draw_rect(c, 32, 32, 176, 48, 3, outline_idx=4)

        draw_text(c, 16, 8, title_line, 5, scale=1)
        draw_text(c, 40, 44, sub_line, 4, scale=1)
        write_indexed_png(png_path, 240, 160, pal, c)


def generate_portraits(gfx_dir, if_missing=False):
    portrait_grit = """# 64x64 4bpp portrait (8x8 flat tiles, no map compression)
-gt
-gB4
-m!
-pn16
"""
    portraits = [
        ("mukou_neutral", "MUKOU", "NEUTRAL", (45, 95, 155), (235, 200, 165)),
        ("mukou_sweat", "MUKOU", "SWEAT", (45, 95, 155), (215, 190, 165)),
        ("mukou_confident", "MUKOU", "CONFID", (55, 115, 180), (240, 205, 170)),
        ("magistrate_neutral", "MAGIST", "NEUTRAL", (165, 130, 35), (235, 195, 155)),
        ("magistrate_shout", "MAGIST", "ALLEZ!", (200, 150, 40), (245, 200, 160)),
        ("scribe_neutral", "SCRIBE", "NEUTRAL", (95, 45, 115), (225, 195, 175)),
        ("scribe_smug", "SCRIBE", "SMUG", (115, 45, 135), (230, 200, 180)),
        ("witness_neutral", "WITNES", "NEUTRAL", (60, 120, 75), (235, 200, 165)),
        ("witness_sweat", "WITNES", "SWEAT", (50, 105, 70), (215, 190, 165)),
        ("ohta_neutral", "OHTA", "DESK", (150, 55, 45), (235, 200, 165)),
        ("fukui_neutral", "FUKUI", "DESK", (45, 115, 125), (235, 200, 165)),
    ]

    for filename, label1, label2, robe_rgb, skin_rgb in portraits:
        png_path = os.path.join(gfx_dir, f"{filename}.png")
        grit_path = os.path.join(gfx_dir, f"{filename}.grit")
        write_grit(grit_path, portrait_grit)
        if if_missing and os.path.exists(png_path):
            continue

        pal = [
            TRANSPARENT_RGB,      # 0 transparent
            (28, 24, 36),         # 1 dark outline
            robe_rgb,             # 2 robe primary
            skin_rgb,             # 3 skin tone
            (245, 242, 232),      # 4 white/highlight
            (218, 176, 58),       # 5 gold frame/accent
            (90, 180, 245),       # 6 sweat drop / cyan
            (48, 42, 58),         # 7 portrait frame bg
        ]
        c = make_canvas(64, 64, fill_idx=0)
        # Portrait backing box with 2px transparent margin
        draw_rect(c, 2, 2, 60, 60, 7, outline_idx=5)
        # Shoulders / kimono
        draw_rect(c, 10, 38, 44, 22, 2, outline_idx=1)
        # Head silhouette
        draw_rect(c, 18, 12, 28, 26, 3, outline_idx=1)
        # Hair / topknot bar
        draw_rect(c, 18, 10, 28, 6, 1)
        # Eyes & mouth based on expression
        if "sweat" in filename:
            draw_rect(c, 23, 22, 5, 2, 1)
            draw_rect(c, 36, 22, 5, 2, 1)
            draw_rect(c, 27, 30, 10, 3, 1)
            # Blue sweat drop on temple
            draw_rect(c, 42, 16, 4, 6, 6)
        elif "shout" in filename or "confident" in filename or "smug" in filename:
            draw_rect(c, 23, 21, 5, 3, 1)
            draw_rect(c, 36, 21, 5, 3, 1)
            draw_rect(c, 26, 29, 12, 5, 4, outline_idx=1)
        else:
            draw_rect(c, 24, 22, 4, 3, 1)
            draw_rect(c, 36, 22, 4, 3, 1)
            draw_rect(c, 28, 31, 8, 2, 1)

        draw_text(c, 6, 4, label1, 4, scale=1)
        draw_text(c, 6, 54, label2, 4, scale=1)
        write_indexed_png(png_path, 64, 64, pal, c)


def generate_sprites(gfx_dir, if_missing=False):
    spr_grit = """# 16x16 4bpp OBJ sprite
-gt
-gB4
-m!
-pn16
"""
    sprites = [
        ("ev_plum_jar", "JR", (175, 50, 65), (240, 215, 190)),
        ("ev_tea_receipt", "RC", (225, 215, 180), (60, 50, 40)),
        ("ev_nori_scrap", "NR", (35, 75, 45), (220, 235, 210)),
        ("ev_guard_log", "LG", (85, 115, 165), (240, 235, 220)),
        ("spr_cursor", "CR", (250, 215, 45), (30, 20, 10)),
        ("spr_pip_full", "OK", (75, 205, 95), (25, 60, 30)),
        ("spr_pip_empty", "--", (90, 85, 95), (35, 30, 40)),
        ("spr_qte", "L!", (235, 70, 45), (255, 245, 220)),
    ]

    for filename, tag, main_rgb, text_rgb in sprites:
        png_path = os.path.join(gfx_dir, f"{filename}.png")
        grit_path = os.path.join(gfx_dir, f"{filename}.grit")
        write_grit(grit_path, spr_grit)
        if if_missing and os.path.exists(png_path):
            continue

        pal = [
            TRANSPARENT_RGB,
            (20, 18, 24),
            main_rgb,
            text_rgb,
            (245, 205, 65),
        ]
        c = make_canvas(16, 16, fill_idx=0)
        if filename == "spr_cursor":
            # Targeting brackets around edges with transparent center
            draw_rect(c, 1, 1, 14, 14, 0, outline_idx=2)
            draw_rect(c, 0, 0, 16, 16, 0, outline_idx=1)
            c[7][7] = 2
            c[7][8] = 2
            c[8][7] = 2
            c[8][8] = 2
        else:
            draw_rect(c, 1, 1, 14, 14, 2, outline_idx=1)
            draw_text(c, 4, 5, tag, 3, scale=1)
        write_indexed_png(png_path, 16, 16, pal, c)


def main():
    if_missing = "--if-missing" in sys.argv
    repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    gfx_dir = os.path.join(repo_root, "graphics")
    os.makedirs(gfx_dir, exist_ok=True)
    generate_backgrounds(gfx_dir, if_missing=if_missing)
    generate_portraits(gfx_dir, if_missing=if_missing)
    generate_sprites(gfx_dir, if_missing=if_missing)
    print(f"[make_placeholders] Verified 24 assets in {gfx_dir}")


if __name__ == "__main__":
    main()
