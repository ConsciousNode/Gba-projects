#!/usr/bin/env python3
# Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks
# SPDX-License-Identifier: MIT
#
# tools/wacc.py — Wrongfully Accused Script Compiler
# Compiles script/evidence.wa and script/case1.wa into source/script_data.c and
# include/script_data.h using only the Python 3 standard library.
# Performs compile-time word-wrapping (3 lines x 28 chars) and validates all
# scenes, evidence IDs, flags, portraits, backgrounds, and testimony blocks.

import os
import re
import sys

MAX_LINE_CHARS = 28
MAX_BOX_LINES = 3

VALID_SPEAKERS = {
    "NARRATOR": "SPEAKER_NARRATOR",
    "MUKOU": "SPEAKER_MUKOU",
    "MAGISTRATE": "SPEAKER_MAGISTRATE",
    "SCRIBE": "SPEAKER_SCRIBE",
    "WITNESS": "SPEAKER_WITNESS",
    "OHTA": "SPEAKER_OHTA",
    "FUKUI": "SPEAKER_FUKUI",
    "MERCHANT": "SPEAKER_WITNESS",
    "MUSICIAN": "SPEAKER_OHTA",
}

VALID_PORTRAITS = {
    ("none", "none"): "PORTRAIT_NONE",
    ("mukou", "neutral"): "PORTRAIT_MUKOU_NEUTRAL",
    ("mukou", "sweat"): "PORTRAIT_MUKOU_SWEAT",
    ("mukou", "confident"): "PORTRAIT_MUKOU_CONFIDENT",
    ("magistrate", "neutral"): "PORTRAIT_MAGISTRATE_NEUTRAL",
    ("magistrate", "shout"): "PORTRAIT_MAGISTRATE_SHOUT",
    ("scribe", "neutral"): "PORTRAIT_SCRIBE_NEUTRAL",
    ("scribe", "smug"): "PORTRAIT_SCRIBE_SMUG",
    ("witness", "neutral"): "PORTRAIT_WITNESS_NEUTRAL",
    ("witness", "sweat"): "PORTRAIT_WITNESS_SWEAT",
    ("ohta", "neutral"): "PORTRAIT_OHTA_NEUTRAL",
    ("fukui", "neutral"): "PORTRAIT_FUKUI_NEUTRAL",
}

VALID_BGS = {
    "title": "BG_ID_TITLE",
    "teahouse": "BG_ID_TEAHOUSE",
    "court": "BG_ID_COURT",
    "charge": "BG_ID_CHARGE",
    "verdict": "BG_ID_VERDICT",
}

VALID_SFX = {
    "blip": "SFX_BLIP",
    "objection": "SFX_OBJECTION",
    "wrong": "SFX_WRONG",
    "gavel": "SFX_GAVEL",
    "sanshin": "SFX_SANSHIN",
    "ding": "SFX_DING",
}

VALID_BUTTONS = {
    "A": "QTE_BTN_A",
    "B": "QTE_BTN_B",
    "L": "QTE_BTN_L",
    "R": "QTE_BTN_R",
}

VALID_ICONS = {
    "ev_plum_jar": "ICON_PLUM_JAR",
    "ev_tea_receipt": "ICON_TEA_RECEIPT",
    "ev_nori_scrap": "ICON_NORI_SCRAP",
    "ev_guard_log": "ICON_GUARD_LOG",
}


class CompileError(Exception):
    def __init__(self, filename, lineno, message):
        super().__init__(f"{os.path.basename(filename)} line {lineno}: {message}")
        self.filename = filename
        self.lineno = lineno
        self.message = message


def wrap_dialogue(text, filename, lineno, context="dialogue line"):
    """Wrap ASCII text at word boundaries into at most 3 lines of 28 chars."""
    for ch in text:
        if ord(ch) < 32 or ord(ch) > 126:
            raise CompileError(
                filename,
                lineno,
                f'{context} contains non-ASCII character "{ch}" (only ASCII 32-126 allowed)',
            )

    words = text.strip().split()
    if not words:
        raise CompileError(filename, lineno, f"{context} is empty")

    lines = []
    current = ""
    for word in words:
        if len(word) > MAX_LINE_CHARS:
            raise CompileError(
                filename,
                lineno,
                f'word "{word}" is {len(word)} characters long (maximum is {MAX_LINE_CHARS})',
            )
        if not current:
            current = word
        elif len(current) + 1 + len(word) <= MAX_LINE_CHARS:
            current += " " + word
        else:
            lines.append(current)
            current = word

    if current:
        lines.append(current)

    if len(lines) > MAX_BOX_LINES:
        raise CompileError(
            filename,
            lineno,
            f'{context} wraps to {len(lines)} lines, which is too long to fit in '
            f'a {MAX_BOX_LINES}-line x {MAX_LINE_CHARS}-character box: "{text}"',
        )

    return "\n".join(lines)


def c_escape(s):
    return (
        s.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\n", "\\n")
    )


def parse_evidence_file(path):
    """Parse script/evidence.wa into a list of dicts."""
    evidence_list = []
    seen_ids = set()

    with open(path, "r", encoding="utf-8") as f:
        raw_lines = f.readlines()

    current = None
    for idx, raw in enumerate(raw_lines, start=1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue

        if current is None:
            if line.startswith("evidence "):
                ev_id = line[len("evidence ") :].strip()
                if not re.match(r"^[a-zA-Z0-9_]+$", ev_id):
                    raise CompileError(path, idx, f'invalid evidence id "{ev_id}"')
                if ev_id in seen_ids:
                    raise CompileError(path, idx, f'duplicate evidence id "{ev_id}"')
                seen_ids.add(ev_id)
                current = {"id": ev_id, "lineno": idx, "name": None, "desc": None, "icon": None}
            else:
                raise CompileError(path, idx, f'expected "evidence <id>", got "{line}"')
        else:
            if line == "end":
                for field in ("name", "desc", "icon"):
                    if not current[field]:
                        raise CompileError(
                            path,
                            idx,
                            f'evidence "{current["id"]}" is missing "{field}"',
                        )
                evidence_list.append(current)
                current = None
            elif line.startswith("name "):
                val = line[5:].strip().strip('"')
                if len(val) > 22:
                    raise CompileError(
                        path,
                        idx,
                        f'evidence name "{val}" exceeds 22 characters ({len(val)})',
                    )
                current["name"] = val
            elif line.startswith("desc "):
                val = line[5:].strip().strip('"')
                current["desc"] = wrap_dialogue(val, path, idx, "evidence description")
            elif line.startswith("icon "):
                val = line[5:].strip()
                if val not in VALID_ICONS:
                    raise CompileError(
                        path,
                        idx,
                        f'unknown evidence icon "{val}" (valid: {", ".join(sorted(VALID_ICONS))})',
                    )
                current["icon"] = VALID_ICONS[val]
            else:
                raise CompileError(
                    path,
                    idx,
                    f'unknown field inside evidence block: "{line}"',
                )

    if current is not None:
        raise CompileError(
            path,
            current["lineno"],
            f'evidence "{current["id"]}" block was never closed with "end"',
        )

    return evidence_list


def parse_kv_args(tokens, filename, lineno):
    kv = {}
    for tok in tokens:
        if "=" not in tok:
            raise CompileError(filename, lineno, f'expected key=value argument, got "{tok}"')
        k, v = tok.split("=", 1)
        kv[k.strip()] = v.strip()
    return kv


def parse_case_file(path, evidence_map):
    with open(path, "r", encoding="utf-8") as f:
        raw_lines = f.readlines()

    scenes = {}          # scene_name -> instruction index
    scene_order = []     # list of scene_names in order
    instructions = []    # list of instruction dicts
    flags = {}           # flag_name -> int index
    testimonies = []     # list of testimony dicts
    scene_refs = []      # list of (target_scene, filename, lineno)
    evidence_refs = []   # list of (ev_id, filename, lineno)

    def get_flag_id(name, lineno):
        if not re.match(r"^[a-zA-Z0-9_]+$", name):
            raise CompileError(path, lineno, f'invalid flag name "{name}"')
        if name not in flags:
            if len(flags) >= 32:
                raise CompileError(path, lineno, "maximum of 32 script flags exceeded")
            flags[name] = len(flags)
        return flags[name]

    in_testimony = None

    for idx, raw in enumerate(raw_lines, start=1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue

        # Inside a testimony block
        if in_testimony is not None:
            if line == "end":
                t = in_testimony
                if len(t["statements"]) != 4:
                    raise CompileError(
                        path,
                        t["lineno"],
                        f'testimony "{t["name"]}" has {len(t["statements"])} statements '
                        f"(must have exactly 4 statements)",
                    )
                contradictions = [
                    s for s in t["statements"] if s["contradicted_by"] is not None
                ]
                if len(contradictions) != 1:
                    raise CompileError(
                        path,
                        t["lineno"],
                        f'testimony "{t["name"]}" has {len(contradictions)} contradictions '
                        f"(must have exactly 1 statement with contradicted_by)",
                    )
                if not t["wrong_present"]:
                    raise CompileError(
                        path,
                        t["lineno"],
                        f'testimony "{t["name"]}" is missing wrong_present=<scene>',
                    )
                t_id = len(testimonies)
                testimonies.append(t)
                instructions.append(
                    {
                        "op": "OP_TESTIMONY",
                        "arg1": t_id,
                        "arg2": 0,
                        "arg3": 0,
                        "text": None,
                        "lineno": t["lineno"],
                    }
                )
                in_testimony = None
                continue

            if line.startswith("wrong_present="):
                target = line.split("=", 1)[1].strip()
                in_testimony["wrong_present"] = target
                scene_refs.append((target, path, idx))
                continue

            if line.startswith("statement "):
                # Format: statement "text..." press=<scene> [contradicted_by=<ev> success=<scene>] [revise_flag=<flag> revised_text="..."]
                m = re.match(r'^statement\s+"([^"]+)"\s+(.*)$', line)
                if not m:
                    raise CompileError(
                        path,
                        idx,
                        'malformed statement; expected: statement "text" press=<scene> [...]',
                    )
                stmt_text_raw = m.group(1)
                rest = m.group(2).strip()
                # Extract optional revised_text="..." first if present
                revised_text_wrapped = None
                rev_m = re.search(r'revised_text="([^"]+)"', rest)
                if rev_m:
                    revised_text_wrapped = wrap_dialogue(
                        rev_m.group(1), path, idx, "revised statement text"
                    )
                    rest = (rest[: rev_m.start()] + rest[rev_m.end() :]).strip()

                kv = parse_kv_args(rest.split(), path, idx)
                if "press" not in kv:
                    raise CompileError(path, idx, "statement is missing press=<scene>")
                press_scene = kv["press"]
                scene_refs.append((press_scene, path, idx))

                contra_ev = kv.get("contradicted_by")
                success_scene = kv.get("success")
                if contra_ev is not None:
                    evidence_refs.append((contra_ev, path, idx))
                    if not success_scene:
                        raise CompileError(
                            path,
                            idx,
                            f'statement with contradicted_by="{contra_ev}" is missing success=<scene>',
                        )
                    scene_refs.append((success_scene, path, idx))
                elif success_scene is not None:
                    raise CompileError(
                        path,
                        idx,
                        "statement has success=<scene> without contradicted_by=<evidence_id>",
                    )

                revise_flag_id = -1
                if "revise_flag" in kv:
                    revise_flag_id = get_flag_id(kv["revise_flag"], idx)
                    if not revised_text_wrapped:
                        raise CompileError(
                            path,
                            idx,
                            'statement with revise_flag must also provide revised_text="..."',
                        )

                in_testimony["statements"].append(
                    {
                        "text": wrap_dialogue(stmt_text_raw, path, idx, "testimony statement"),
                        "press_scene": press_scene,
                        "contradicted_by": contra_ev,
                        "success_scene": success_scene,
                        "revise_flag_id": revise_flag_id,
                        "revised_text": revised_text_wrapped,
                        "lineno": idx,
                    }
                )
                continue

            raise CompileError(path, idx, f'unexpected line inside testimony block: "{line}"')

        # Scene label: @scene <name>
        if line.startswith("@scene "):
            scene_name = line[len("@scene ") :].strip()
            if not re.match(r"^[a-zA-Z0-9_]+$", scene_name):
                raise CompileError(path, idx, f'invalid scene name "{scene_name}"')
            if scene_name in scenes:
                raise CompileError(path, idx, f'duplicate scene definition "{scene_name}"')
            scenes[scene_name] = len(instructions)
            scene_order.append(scene_name)
            continue

        if not scene_order:
            raise CompileError(path, idx, "commands must appear inside a @scene block")

        # Start testimony block
        if line.startswith("testimony"):
            parts = line.split()
            t_name = parts[1] if len(parts) > 1 else f"testimony_{len(testimonies)}"
            in_testimony = {
                "name": t_name,
                "lineno": idx,
                "statements": [],
                "wrong_present": None,
            }
            continue

        # Speaker line: SPEAKER: text...
        speaker_match = re.match(r"^([A-Z_]+):\s*(.+)$", line)
        if speaker_match:
            spk = speaker_match.group(1)
            txt = speaker_match.group(2)
            if spk not in VALID_SPEAKERS:
                raise CompileError(
                    path,
                    idx,
                    f'unknown speaker "{spk}" (valid: {", ".join(sorted(VALID_SPEAKERS))})',
                )
            wrapped = wrap_dialogue(txt, path, idx, f"{spk} dialogue")
            instructions.append(
                {
                    "op": "OP_SAY",
                    "arg1": VALID_SPEAKERS[spk],
                    "arg2": 0,
                    "arg3": 0,
                    "text": wrapped,
                    "lineno": idx,
                }
            )
            continue

        tokens = line.split()
        cmd = tokens[0]

        if cmd == "portrait":
            if len(tokens) == 2 and tokens[1] == "none":
                key = ("none", "none")
            elif len(tokens) == 3:
                key = (tokens[1].lower(), tokens[2].lower())
            else:
                raise CompileError(
                    path, idx, 'expected "portrait <character> <expression>" or "portrait none"'
                )
            if key not in VALID_PORTRAITS:
                raise CompileError(
                    path,
                    idx,
                    f'unknown portrait "{ " ".join(tokens[1:]) }"',
                )
            instructions.append(
                {
                    "op": "OP_PORTRAIT",
                    "arg1": VALID_PORTRAITS[key],
                    "arg2": 0,
                    "arg3": 0,
                    "text": None,
                    "lineno": idx,
                }
            )

        elif cmd == "bg":
            if len(tokens) != 2 or tokens[1] not in VALID_BGS:
                raise CompileError(
                    path,
                    idx,
                    f'unknown background "{line}" (valid: {", ".join(sorted(VALID_BGS))})',
                )
            instructions.append(
                {
                    "op": "OP_BG",
                    "arg1": VALID_BGS[tokens[1]],
                    "arg2": 0,
                    "arg3": 0,
                    "text": None,
                    "lineno": idx,
                }
            )

        elif cmd == "sfx":
            if len(tokens) != 2 or tokens[1] not in VALID_SFX:
                raise CompileError(
                    path,
                    idx,
                    f'unknown sfx "{line}" (valid: {", ".join(sorted(VALID_SFX))})',
                )
            instructions.append(
                {
                    "op": "OP_SFX",
                    "arg1": VALID_SFX[tokens[1]],
                    "arg2": 0,
                    "arg3": 0,
                    "text": None,
                    "lineno": idx,
                }
            )

        elif cmd == "give":
            if len(tokens) != 2:
                raise CompileError(path, idx, 'expected "give <evidence_id>"')
            ev_id = tokens[1]
            evidence_refs.append((ev_id, path, idx))
            instructions.append(
                {
                    "op": "OP_GIVE",
                    "arg1": ev_id,  # resolved later
                    "arg2": 0,
                    "arg3": 0,
                    "text": None,
                    "lineno": idx,
                }
            )

        elif cmd == "flag":
            if len(tokens) != 3 or tokens[1] != "set":
                raise CompileError(path, idx, 'expected "flag set <name>"')
            fid = get_flag_id(tokens[2], idx)
            instructions.append(
                {
                    "op": "OP_FLAG_SET",
                    "arg1": fid,
                    "arg2": 0,
                    "arg3": 0,
                    "text": None,
                    "lineno": idx,
                }
            )

        elif cmd == "if":
            if (
                len(tokens) == 5
                and tokens[1] == "has"
                and tokens[3] == "goto"
            ):
                ev_id = tokens[2]
                target = tokens[4]
                evidence_refs.append((ev_id, path, idx))
                scene_refs.append((target, path, idx))
                instructions.append(
                    {
                        "op": "OP_IF_HAS_GOTO",
                        "arg1": ev_id,
                        "arg2": target,
                        "arg3": 0,
                        "text": None,
                        "lineno": idx,
                    }
                )
            elif (
                len(tokens) == 5
                and tokens[1] == "flag"
                and tokens[3] == "goto"
            ):
                fid = get_flag_id(tokens[2], idx)
                target = tokens[4]
                scene_refs.append((target, path, idx))
                instructions.append(
                    {
                        "op": "OP_IF_FLAG_GOTO",
                        "arg1": fid,
                        "arg2": target,
                        "arg3": 0,
                        "text": None,
                        "lineno": idx,
                    }
                )
            else:
                raise CompileError(
                    path,
                    idx,
                    'expected "if has <evidence_id> goto <scene>" or "if flag <name> goto <scene>"',
                )

        elif cmd == "goto":
            if len(tokens) != 2:
                raise CompileError(path, idx, 'expected "goto <scene>"')
            target = tokens[1]
            scene_refs.append((target, path, idx))
            instructions.append(
                {
                    "op": "OP_GOTO",
                    "arg1": target,
                    "arg2": 0,
                    "arg3": 0,
                    "text": None,
                    "lineno": idx,
                }
            )

        elif cmd == "confidence":
            if len(tokens) != 2:
                raise CompileError(path, idx, 'expected "confidence +1" or "confidence -1"')
            try:
                delta = int(tokens[1])
            except ValueError:
                raise CompileError(path, idx, f'invalid confidence delta "{tokens[1]}"')
            instructions.append(
                {
                    "op": "OP_CONFIDENCE",
                    "arg1": delta,
                    "arg2": 0,
                    "arg3": 0,
                    "text": None,
                    "lineno": idx,
                }
            )

        elif cmd == "qte":
            # qte <button> <frames> success=<scene> fail=<scene>
            if len(tokens) != 5:
                raise CompileError(
                    path,
                    idx,
                    'expected "qte <button> <frames> success=<scene> fail=<scene>"',
                )
            btn = tokens[1].upper()
            if btn not in VALID_BUTTONS:
                raise CompileError(
                    path,
                    idx,
                    f'unknown QTE button "{btn}" (valid: {", ".join(sorted(VALID_BUTTONS))})',
                )
            try:
                frames = int(tokens[2])
            except ValueError:
                raise CompileError(path, idx, f'invalid frame count "{tokens[2]}"')
            if frames < 15 or frames > 300:
                raise CompileError(path, idx, f"QTE frames ({frames}) must be between 15 and 300")
            kv = parse_kv_args(tokens[3:], path, idx)
            if "success" not in kv or "fail" not in kv:
                raise CompileError(path, idx, "qte requires both success=<scene> and fail=<scene>")
            scene_refs.append((kv["success"], path, idx))
            scene_refs.append((kv["fail"], path, idx))
            instructions.append(
                {
                    "op": "OP_QTE",
                    "arg1": VALID_BUTTONS[btn],
                    "arg2": frames,
                    "arg3": (kv["success"], kv["fail"]),
                    "text": None,
                    "lineno": idx,
                }
            )

        elif cmd == "charge_reveal":
            m = re.match(r'^charge_reveal\s+"([^"]+)"$', line)
            if not m:
                raise CompileError(path, idx, 'expected: charge_reveal "<charge text>"')
            wrapped_charge = wrap_dialogue(m.group(1), path, idx, "charge_reveal text")
            instructions.append(
                {
                    "op": "OP_CHARGE_REVEAL",
                    "arg1": 0,
                    "arg2": 0,
                    "arg3": 0,
                    "text": wrapped_charge,
                    "lineno": idx,
                }
            )

        elif cmd == "investigate":
            instructions.append(
                {
                    "op": "OP_INVESTIGATE",
                    "arg1": 0,
                    "arg2": 0,
                    "arg3": 0,
                    "text": None,
                    "lineno": idx,
                }
            )

        elif cmd == "return_testimony":
            instructions.append(
                {
                    "op": "OP_RETURN_TESTIMONY",
                    "arg1": 0,
                    "arg2": 0,
                    "arg3": 0,
                    "text": None,
                    "lineno": idx,
                }
            )

        elif cmd == "ending":
            if len(tokens) != 2 or tokens[1] not in ("good", "bad"):
                raise CompileError(path, idx, 'expected "ending good" or "ending bad"')
            instructions.append(
                {
                    "op": "OP_ENDING",
                    "arg1": 1 if tokens[1] == "good" else 0,
                    "arg2": 0,
                    "arg3": 0,
                    "text": None,
                    "lineno": idx,
                }
            )

        else:
            raise CompileError(path, idx, f'unknown script command "{cmd}"')

    if in_testimony is not None:
        raise CompileError(
            path,
            in_testimony["lineno"],
            f'testimony "{in_testimony["name"]}" was never closed with "end"',
        )

    # Validate all referenced evidence IDs
    for ev_id, ref_file, ref_line in evidence_refs:
        if ev_id not in evidence_map:
            raise CompileError(
                ref_file,
                ref_line,
                f'evidence "{ev_id}" is never defined in evidence.wa',
            )

    # Validate all referenced scenes
    for target_scene, ref_file, ref_line in scene_refs:
        if target_scene not in scenes:
            raise CompileError(
                ref_file,
                ref_line,
                f'scene "{target_scene}" is never defined',
            )

    # Validate required entry-point scenes for the vertical slice
    required_scenes = [
        "intro",
        "hotspot_merchant",
        "hotspot_musician",
        "hotspot_jar",
        "action_sanshin",
        "action_go_court",
        "court_start",
        "no_confidence",
    ]
    for req in required_scenes:
        if req not in scenes:
            raise CompileError(
                path,
                1,
                f'required entry-point scene "@scene {req}" is missing from {os.path.basename(path)}',
            )

    return scenes, instructions, flags, testimonies


def emit_c_files(c_path, h_path, evidence_list, scenes, instructions, flags, testimonies):
    evidence_map = {ev["id"]: i for i, ev in enumerate(evidence_list)}

    h_lines = [
        "/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks */",
        "/* SPDX-License-Identifier: MIT */",
        "/* AUTO-GENERATED BY tools/wacc.py — DO NOT EDIT BY HAND */",
        "",
        "#ifndef SCRIPT_DATA_H",
        "#define SCRIPT_DATA_H",
        "",
        "#include \"script_vm.h\"",
        "",
        f"#define EVIDENCE_COUNT {len(evidence_list)}",
        f"#define SCRIPT_INSN_COUNT {len(instructions)}",
        f"#define SCRIPT_FLAG_COUNT {max(1, len(flags))}",
        f"#define SCRIPT_TESTIMONY_COUNT {max(1, len(testimonies))}",
        "",
    ]

    for i, ev in enumerate(evidence_list):
        h_lines.append(f"#define EV_{ev['id'].upper()} {i}")
    h_lines.append("")

    for s_name, s_pc in sorted(scenes.items()):
        h_lines.append(f"#define SCENE_{s_name.upper()} {s_pc}u")
    h_lines.append("")

    for f_name, f_id in sorted(flags.items()):
        h_lines.append(f"#define FLAG_{f_name.upper()} {f_id}u")
    h_lines.append("")

    h_lines.extend(
        [
            "extern const EvidenceDef g_evidence_defs[EVIDENCE_COUNT];",
            "extern const ScriptInsn g_script_insns[SCRIPT_INSN_COUNT];",
            "extern const TestimonyDef g_testimonies[SCRIPT_TESTIMONY_COUNT];",
            "",
            "#endif /* SCRIPT_DATA_H */",
            "",
        ]
    )

    c_lines = [
        "/* Copyright (c) 2026 Khamerron Kizer / ConsciousNode SoftWorks */",
        "/* SPDX-License-Identifier: MIT */",
        "/* AUTO-GENERATED BY tools/wacc.py — DO NOT EDIT BY HAND */",
        "",
        "#include \"script_data.h\"",
        "",
        "const EvidenceDef g_evidence_defs[EVIDENCE_COUNT] = {",
    ]
    for ev in evidence_list:
        c_lines.append(
            f'    {{ "{c_escape(ev["name"])}", "{c_escape(ev["desc"])}", {ev["icon"]} }},'
        )
    c_lines.append("};")
    c_lines.append("")

    c_lines.append("const TestimonyDef g_testimonies[SCRIPT_TESTIMONY_COUNT] = {")
    for t in testimonies:
        c_lines.append("    {")
        c_lines.append(f"        .wrong_present_pc = {scenes[t['wrong_present']]}u,")
        c_lines.append("        .statements = {")
        for s in t["statements"]:
            contra_idx = (
                evidence_map[s["contradicted_by"]]
                if s["contradicted_by"] is not None
                else -1
            )
            succ_pc = (
                scenes[s["success_scene"]]
                if s["success_scene"] is not None
                else 0
            )
            rev_txt = (
                f'"{c_escape(s["revised_text"])}"'
                if s["revised_text"] is not None
                else "0"
            )
            c_lines.append(
                f"            {{ "
                f'"{c_escape(s["text"])}", '
                f"{rev_txt}, "
                f"{scenes[s['press_scene']]}u, "
                f"{contra_idx}, "
                f"{succ_pc}u, "
                f"{s['revise_flag_id']} "
                f"}},"
            )
        c_lines.append("        }")
        c_lines.append("    },")
    c_lines.append("};")
    c_lines.append("")

    c_lines.append("const ScriptInsn g_script_insns[SCRIPT_INSN_COUNT] = {")
    for insn in instructions:
        op = insn["op"]
        a1 = insn["arg1"]
        a2 = insn["arg2"]
        a3 = insn["arg3"]
        txt = f'"{c_escape(insn["text"])}"' if insn["text"] is not None else "0"

        if op == "OP_GIVE":
            a1 = evidence_map[a1]
        elif op == "OP_IF_HAS_GOTO":
            a1 = evidence_map[a1]
            a2 = scenes[a2]
        elif op == "OP_IF_FLAG_GOTO":
            a2 = scenes[a2]
        elif op == "OP_GOTO":
            a1 = scenes[a1]
        elif op == "OP_QTE":
            succ_scene, fail_scene = a3
            c_lines.append(
                f"    {{ {op}, {a1}, {insn['arg2']}, {scenes[succ_scene]}, {scenes[fail_scene]}, {txt} }},"
            )
            continue

        c_lines.append(f"    {{ {op}, {a1}, {a2}, {a3}, 0, {txt} }},")

    c_lines.append("};")
    c_lines.append("")

    os.makedirs(os.path.dirname(h_path), exist_ok=True)
    os.makedirs(os.path.dirname(c_path), exist_ok=True)
    with open(h_path, "w", encoding="utf-8") as f:
        f.write("\n".join(h_lines))
    with open(c_path, "w", encoding="utf-8") as f:
        f.write("\n".join(c_lines))


def main():
    if len(sys.argv) != 5:
        print(
            "Usage: python3 tools/wacc.py <evidence.wa> <case1.wa> <out.c> <out.h>",
            file=sys.stderr,
        )
        sys.exit(2)

    ev_path, case_path, out_c, out_h = sys.argv[1:5]
    try:
        evidence_list = parse_evidence_file(ev_path)
        evidence_map = {ev["id"]: i for i, ev in enumerate(evidence_list)}
        scenes, instructions, flags, testimonies = parse_case_file(case_path, evidence_map)
        emit_c_files(out_c, out_h, evidence_list, scenes, instructions, flags, testimonies)
        dialogue_count = sum(1 for i in instructions if i["op"] == "OP_SAY")
        print(
            f"[wacc] Compiled {len(evidence_list)} evidence items, "
            f"{len(scenes)} scenes, {dialogue_count} dialogue boxes, "
            f"{len(testimonies)} testimony blocks -> {os.path.basename(out_c)}"
        )
    except CompileError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
