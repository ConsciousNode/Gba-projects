# Wrongfully Accused of Stealin' From the Shogunate (GBA Vertical Slice)

**ConsciousNode SoftWorks** · MIT License · Game Boy Advance (`240×160`, Mode 0)

This repository is the first playable vertical slice of **Wrongfully Accused of Stealin' From the Shogunate**, an Edo-period courtroom comedy where Ryukyuan bard **Mukou** defends himself against absurd Shogunate indictments without knowing the charge until he steps into court.

---

## 1. Building the ROM (`wrongfully-accused.gba`)

### Prerequisites
- **devkitPro** with the `gba-dev` package group installed (`devkitARM`, `libtonc`, `grit`, `gbafix`).
- **Python 3** (standard library only; no `pip install` needed).

### On Windows (using devkitPro's MSYS2 shell)
1. Open the **MSYS2** shell installed with devkitPro (`C:\devkitPro\msys2\msys2_shell.cmd -mingw64`).
2. Navigate to the project folder (for example, if unpacked on your Desktop):
   ```bash
   cd /c/Users/YOUR_USERNAME/Desktop/wrongfully-accused

 * Build the ROM:
   make

 * When make finishes, you will have wrongfully-accused.gba in the project folder.
On Linux
 * Open a terminal and make sure your devkitPro environment variables are loaded:
   export DEVKITPRO=/opt/devkitpro
export DEVKITARM=/opt/devkitpro/devkitARM
export PATH=$DEVKITARM/bin:$DEVKITPRO/tools/bin:$PATH

 * Navigate to the project folder and run make:
   cd /path/to/wrongfully-accused
make

 * When make finishes, wrongfully-accused.gba is created in the project root.
2. Running in mGBA
 * Desktop GUI: Open mGBA, click File → Load ROM..., and select wrongfully-accused.gba.
 * Command line:
   mgba wrongfully-accused.gba

Controls
| GBA Button | Investigation | Dialogue | Cross-Examination | Court Record |
|---|---|---|---|---|
| D-Pad | Move cursor | — | ← / → Prev / Next statement | Move selection |
| A | Inspect hotspot / Choose menu item | Finish typing line / Advance | Finish typing / Next statement | Present selected evidence |
| B | Close menu | — | — | Close Court Record |
| L | — | — | Press statement | — |
| R | Open Court Record (View) | — | Open Court Record (Present) | — |
| START | Open Menu (Play sanshin / Go to court) | — | — | — |
3. What to Do If make Fails (Top 3 Causes & Fixes)
 * Please set DEVKITARM in your environment
   * Cause: You opened a plain Windows Command Prompt / PowerShell instead of the devkitPro MSYS2 shell, or your Linux shell hasn't exported DEVKITARM.
   * Fix: On Windows, launch MSYS2 from the Start Menu (devkitPro -> MSYS2). On Linux, run:
     export DEVKITPRO=/opt/devkitpro
export DEVKITARM=/opt/devkitpro/devkitARM

 * grit: command not found or tonc.h: No such file or directory
   * Cause: devkitARM is installed, but the GBA helper tools (grit, gbafix) or libtonc from the gba-dev package group are missing.
   * Fix: Inside the devkitPro MSYS2 shell (or with sudo on Linux), install the full gba-dev group:
     pacman -S gba-dev

 * ERROR: case1.wa line XX: ... during [wacc] Compiling .wa scripts...
   * Cause: A script edit in script/case1.wa or script/evidence.wa has a typo in a scene/evidence name, or a dialogue line is too long to fit inside a 3-line × 28-character GBA text box.
   * Fix: Read the exact file name and line number printed by wacc.py, shorten the line or fix the label name, and run make again. See docs/SCRIPT_GUIDE.md for full details.
